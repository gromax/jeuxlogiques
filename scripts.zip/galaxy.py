from typing import List, Optional
from cadre import Cadre

class Cell:
    __line: int
    __col:int
    __owner:int
    __locked:bool

    def __init__(self, line:int, col:int, index:int):
        self.__line = line
        self.__col = col
        self.__index = index
        self.__owner = -1
        self.__locked = False

    def lock(self):
        self.__locked = True

    def is_neighbour(self, other:"Cell")->bool:
        return self.__line == other.__line and abs(self.__col-other.__col)   == 1 \
            or self.__col  == other.__col  and abs(self.__line-other.__line) == 1

    def free_owner(self):
        if not self.__locked:
            self.__owner = -1

    def assign_owner(self, owner:int):
        assert owner >= 0
        assert not self.__locked or self.__owner == owner
        self.__owner = owner

    @classmethod
    def connexe(cls, cells:List["Cell"]) -> bool:
        if len(cells)<=1:
            return True
        conn = [cells[0]]
        neighbour_found = True
        while neighbour_found:
            neighbour_found = False
            for c in cells:
                if c in conn:
                    continue
                if c.has_neighbour(conn):
                    neighbour_found = True
                    conn.append(c)
        return len(conn) == len(cells)

    def has_neighbour(self, cells:List["Cell"]) -> bool:
        """
        renvoie True si self a au moins un voisin dans cells
        """
        for c in cells:
            if self.is_neighbour(c):
                return True
        return False

    @property
    def x(self) -> float:
        return self.__col + 0.5

    @property
    def y(self) -> float:
        return self.__line + 0.5

    @property
    def line(self) -> int:
        return self.__line

    @property
    def col(self) -> int:
        return self.__col

    @property
    def index(self) -> int:
        return self.__index

    @property
    def owner(self) -> int:
        return self.__owner

    @property
    def locked(self) -> bool:
        return self.__locked

    def belongs_star(self, xstar:float, ystar:float) -> bool:
        return max(abs(self.x-xstar), abs(self.y-ystar)) <= 0.5
    
    def cadre(self) -> Cadre:
        return Cadre.square(self.line, self.col)




class Star:
    def __init__(self, line:int, col:int, index:int):
        self.__line = line
        self.__col = col
        self.__index = index
    
    @property
    def line(self) -> int:
        return self.__line

    @property
    def col(self) -> int:
        return self.__col
    
    @property
    def index(self) -> int:
        return self.__index

    @property
    def x(self) -> float:
        return self.__col/2

    @property
    def y(self) -> float:
        return self.__line/2
    

class Solution:
    __iCell:int
    __cells:List[Cell]
    __pile:List[int]
    __stars:List[Star]
    __size:int
    __echec:bool

    def __init__(self, size:int, stars:List[Star], proposition:List[int]=[]):
        self.__echec = False
        self.__stars = stars
        self.__cells = [Cell(i//size, i%size, i) for i in range(size**2)]
        for c in self.__cells:
            self.__link_to_forced_star(c)
        for i,p in enumerate(proposition):
            assert i<len(self.__cells)
            assert -1<=p<len(stars)
            c = self.__cells[i]
            if p>0:
                c.assign_owner(p)
                c.lock()
        self.__iCell = len(self.__cells)
        for i,c in enumerate(self.__cells):
            if c.owner<0:
                self.__iCell = i
                break
        self.__pile = []
        self.__size = size
        self.__go()

    def __go(self):
        loop_max = 1000000
        while not self.__echec and loop_max > 0:
            loop_max -=1
            self.__assign_next_cell()
            if self.__full():
                if self.isvalid():
                    break
                self.__depile()

        if loop_max == 0:
            print("boucle max atteinte !")
            self.__echec = True

    def __link_to_forced_star(self, c:Cell):
        """
        Si c doit être attaché à une étoile qu'elle touche, alors
        c'est fait et elle est verrouillée
        """
        if c.locked:
            return
        for s in self.__stars:
            if c.belongs_star(s.x, s.y):
                c.assign_owner(s.index)
                c.lock()
                return
    
    def __depile(self):
        """
        dépile les choix fait et remonte au dernier indice cellule avec un choix
        """
        if len(self.__pile)==0:
            print("Aucune solution !")
            self.__iCell = 0
            self.__echec = True
            return
        self.__iCell = self.__pile.pop()
        for cell in self.__cells[self.__iCell+1:]:
            cell.free_owner()

    def __full(self) -> bool:
        if self.__iCell < len(self.__cells):
            return False
        for c in self.__cells:
            if c.owner < 0:
                return False
        return True

    def __symetric(self, star:Star, cell:Cell) -> Optional[Cell]:
        x = 2*star.x - cell.x
        y = 2*star.y - cell.y
        if not 0 < x < self.__size or not 0 < y < self.__size:
            return None
        i = int(y) * self.__size + int(x)
        return self.__cells[i]

    def __assign_with_symetric(self, c:Cell) -> bool:
        for s in self.__stars:
            cs = self.__symetric(s, c)
            if cs is None:
                continue
            if cs.index < c.index and cs.owner == s.index:
                c.assign_owner(cs.owner)
                return True
        return False

    def __str__(self)-> str:
        items = ["  " if c.owner==-1 else f"{c.owner:2d}" for c in self.__cells]
        items_in_lines = ["|".join(items[i:i+self.__size])
                          for i in range(0,self.__size**2, self.__size)]
        out = "\n".join(reversed(items_in_lines))
        if self.__echec:
            out += "\nÉchec !"
        return out

    def __assign_next_cell(self):
        """
        avance d'un pas dans la résolution
        renvoie le prochain indice cellule à décider
        """
        c = self.__cells[self.__iCell]
        if c.locked or self.__assign_with_symetric(c):
            self.__iCell += 1
            return
        # c'est l'heure du choix
        # recherche dans les étoiles pas encore testées
        for s in self.__stars[c.owner+1:]:
            cs = self.__symetric(s,c)
            if cs is None:
                continue
            if cs.owner >=0 and cs.owner != s.index:
                continue
            c.assign_owner(s.index)
            self.__pile.append(self.__iCell)
            self.__iCell +=1
            return
        # aucune étoile ne correspondait
        # il faut remonter d'un cran dans la pile
        self.__depile()

    def __test_symetrie(self, starcells:List[Cell], s:Star) -> bool:
        """
        renvoie True si le jeu de cellules est bien symétrique par rapport à l'étoile
        """
        for c in starcells:
            cs = self.__symetric(s, c)
            if cs is None:
                return False
            if cs not in starcells:
                return False
        return True

    def isvalid(self) -> bool:
        """
        Teste si la solution trouvée est valide
        """
        if not self.__full():
            return False
        for s in self.__stars:
            star_cells = [c for c in self.__cells if c.owner == s.index]
            if not Cell.connexe(star_cells):
                return False
            if not self.__test_symetrie(star_cells, s):
                return False
        return True
    
    def tex(self) -> str:
        if self.__echec or not self.isvalid():
            return ""
        draws = []
        for s in self.__stars:
            star_cells = [c.cadre() for c in self.__cells if c.owner == s.index]
            assert len(star_cells)>0
            c = star_cells[0]
            for sc in star_cells[1:]:
                c = c + sc
            draws.append(c.tex())
        return "\n".join(draws)
    
    @property
    def success(self) -> bool:
        return not self.__echec


class Galaxy:
    __stars: List[Star]
    __size:int
    
    def __init__(self, size:int, positions:list):
        """
        size: nombe de lignes et cols de la grille
              les nœuds sont donc en nombre size+1 x size+1
        positions: tableau de paire (line,col) correspondant aux étoiles
        """
        self.__stars = [Star(line, col, i) for i, (line, col) in enumerate(positions)] 
        self.__size = size

    @classmethod
    def make_from_id(cls, game_id:str):
        """
        game_id: chaine contenant l'id générée par les jeux de simon tatham
        renvoie un objet GalaxyGame
        exemple:
          7x7:agwhoyjrdvzbi
        """
        pre, vals = game_id.split(':')
        ssize, _ = pre.split('x')
        size = int(ssize)
        values = [ord(letter) - ord('a') + 1 for letter in vals]
        t = -1
        S = 2*size-1
        tab_pos = []
        for v in values:
            t += v
            if v == 26:
                t -= 1
                continue
            line = S - t//S
            col = t%S + 1
            tab_pos.append((line,col))
        return Galaxy(size, tab_pos)

    def solve(self, proposition:List[int]=[]):
        return Solution(self.__size, self.__stars, proposition)

    def __tex_stars(self):
        """
        renvoie la grille des étoiles
        """
        lines = [f"{s.x}/{s.y}" for s in self.__stars]
        return "\\foreach \\x/\\y in {%\n" + \
               ",%\n".join(lines) + "%\n" + \
               "} \\draw(\\x,\\y) circle(0.3);\n"

    def __tex_soluce(self):
        sol = self.solve()
        return "\\ifthenelse{\\showCor = 1}{\n" + \
               sol.tex()+ \
               "}{ }"


    def tex(self):
        """
        renvoie la version tex
        """
        return "\n".join([
            "\\begin{tikzpicture}[scale=1]",
            "\\dottedGrid{" + str(self.__size) + "}",
            self.__tex_soluce(),
            self.__tex_stars(),
            "\\end{tikzpicture}"
        ])
    
if __name__ == '__main__':
    game_id = input("id = ")
    s = Galaxy.make_from_id(game_id)
    print(s.tex())



