from typing import Dict

from cadre import Cadre
from value import Value

class Zone:
    def __init__(self, tag):
        self.__tag = tag
        self.__coords:Dict[tuple[int,int], Value] = {}

    @property
    def coords(self) -> list[tuple[int,int]]:
        return list(self.__coords.keys())
    
    @property
    def tag(self) -> str:
        return self.__tag

    def init_possibles(self, possibility:list[int]):
        values_knowns = [v.value for v in self.__coords.values() if v.known]
        p = [it for it in possibility if it not in values_knowns]
        for v in self.__coords.values():
            v.add_possibles(p)

    def cadre(self) -> Cadre:
        c = Cadre()
        for iline, icol in self.__coords:
            c = c + Cadre.square(iline, icol)
        return c

    @property
    def size(self):
        return len(self.__coords)
    
    def add_coord(self, iline, icol, value:Value):
        self.__coords[(iline, icol)] = value

    def assign_value(self, iline, icol, value):
        assert (iline, icol) in self.__coords
        self.__coords[(iline, icol)] = value
    
    def values(self):
        return [f"{c[1]}/{c[0]}/{v}" for c,v in self.__coords.items() if v.known]

    def has_double(self):
        vals = [v.value for v in self.__coords.values() if v.known]
        vals.sort()
        for i in range(len(vals) -1):
            if vals[i] == vals[i+1]:
                return True
        return False