from typing import Union

class Value:
    def __init__(self, initial:int = -1):
        self.__initial = initial
        self.__possibles:tuple[int] = set()
        self.__current = initial
    
    @property
    def value(self) -> int:
        return self.__current

    def add_possible(self, value:int):
        
            self.__possibles.add(value)
    
    def add_possibles(self, values:list[int]):
        if self.__initial != -1:
            return
        p = set()
        for v in values:
            p.add(v)
        self.__possibles = tuple(p)

    def __eq__(self, other:Union[int, "Value"]) -> bool:
        if isinstance(other, int):
            return self.__current == other
        return other.__current == self.__current

    @property
    def known(self) -> bool:
        return self.__current != -1
    
    @property
    def is_initial(self) -> bool:
        return self.__initial != -1

    def __str__(self) -> str:
        return str(self.__current) if self.known else '?'

    def next(self) -> bool:
        if len(self.__possibles) == 0:
            return False
        if self.__current == -1:
            self.__current = self.__possibles[0]
            return True
        i = self.__possibles.index(self.__current)
        if i == len(self.__possibles) - 1:
            self.__current = -1
            return False
        self.__current = self.__possibles[i+1]
        return True
