class Graph:
    def __init__(self):
        self.__nodes = {}

    def add_node(self, name):
        assert name not in self.__nodes
        self.__nodes[name] = []
    
    def add_vertex(self, orig, dest):
        assert orig != dest
        assert orig in self.__nodes
        assert dest in self.__nodes
        assert dest not in self.__nodes[orig]
        assert orig not in self.__nodes[dest]
        self.__nodes[orig].append(dest)
        self.__nodes[dest].append(orig)

    def clone(self):
        g = Graph()
        for n in self.__nodes:
            g.__nodes[n] = self.__nodes[n].copy()
        return g
    
    def __del_orphan(self):
        to_del = []
        for n in self.__nodes:
            if len(self.__nodes[n]) == 0:
                to_del.append(n)
        for n in to_del:
            del self.__nodes[n]
        return len(to_del) > 0
    
    def get_node_of_order_equal(self, n:int):
        """
        renvoie les noms des nœuds d'ordre n
        """
        return [lab for lab in self.__nodes if len(self.__nodes[lab]) == n]

    def get_node_of_order_less(self, n:int):
        """
        renvoie les noms des nœuds d'ordre <= n
        """
        return [lab for lab in self.__nodes if len(self.__nodes[lab]) <= n]

    def remove_node(self, label):
        """
        supprime un nœud en ajustant les connexions
        """
        assert label in self.__nodes
        for lab in self.__nodes[label]:
            self.__nodes[lab].remove(label)
        del self.__nodes[label]

    def remove_nodes(self, labels):
        """
        supprime les nœuds en ajustant les connexions
        """
        for lab in labels:
            self.remove_node(lab)
            
    def __del_single(self):
        to_del = self.get_node_of_order(1)
        self.remove_nodes(to_del)
        for n in to_del:
            if len(self.__nodes[n]) > 0:
                v = self.__nodes[n][0]
                self.__nodes[v].remove(n)
            del self.__nodes[n]
        return len(to_del) > 0

    def __has_cycle_destruc(self):
        """
        cette fonction casse le graphe
        """
        while len(to_del := self.get_node_of_order_less(1)) > 0:
            self.remove_nodes(to_del)
        return len(self.__nodes) > 0
    
    def has_cycle(self) -> bool:
        return self.clone().__has_cycle_destruc()
        
