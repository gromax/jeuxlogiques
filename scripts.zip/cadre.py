from typing import List
from coord import Coord
from segment import Segment

class Cadre:
    """
    définit un cadre tracé dans l'ordre horaire
    """
    def __init__(self):
        self.__segments:List[Segment] = []

    def add_segment(self, s:Segment):
        sopp = s.opposite()
        if sopp in self.__segments:
            self.__segments.remove(sopp)
        else:
            self.__segments.append(s)

    def add_segment_coord(self, iline1:int, icol1:int, iline2:int, icol2:int):
        c1 = Coord(iline1, icol1)
        c2 = Coord(iline2, icol2)
        s = Segment(c1, c2)
        self.add_segment(s)

    @classmethod
    def square(cls, iline:int, icol:int) -> "Cadre":
        c = Cadre()
        c.add_segment_coord(iline, icol, iline, icol+1)
        c.add_segment_coord(iline, icol+1, iline+1, icol+1)
        c.add_segment_coord(iline+1, icol+1, iline+1, icol)
        c.add_segment_coord(iline+1, icol, iline, icol)
        return c
    
    def __add__(self, other:"Cadre") -> "Cadre":
        c = Cadre()
        c.__segments = self.__segments.copy()
        for s in other.__segments:
            c.add_segment(s)
        return c

    def __order(self):
        n = len(self.__segments)
        for i in range(n-2):
            p2 = self.__segments[i].end
            for j in range(i+2, n):
                p3 = self.__segments[j].start
                if p3 == p2:
                    self.__segments[i+1], self.__segments[j] = self.__segments[j], self.__segments[i+1]
                    break

    def tex(self):
        n = len(self.__segments)
        if n == 0:
            return ""
        self.__order()
        all = []
        current_line = [f"\\draw[line width=2pt] {self.__segments[0].start}"]
        for i in range(1, n):
            current = self.__segments[i]
            prec = self.__segments[i-1]
            if not current.is_after(prec):
                current_line.append(str(prec.end))
                all.append("--".join(current_line) + ";")
                current_line = [f"\\draw[line width=2pt] {current.start}"]
            elif not current.is_inline(prec):
                current_line.append(str(current.start))
        current_line.append(str(self.__segments[-1].end))
        all.append("--".join(current_line) + ";")
        return "\n".join(all)
    
if __name__ =='__main__':
    c1 = Cadre.square(2,0)
    c2 = Cadre.square(2,1)
    c3 = Cadre.square(2,2)
    c4 = Cadre.square(2,3)
    c5 = Cadre.square(1,1)
    c = c1  + c2  + c3 + c4 + c5
    print(c.tex())