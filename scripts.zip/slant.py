from graph import Graph

class SoluceSlant:
    EMPTY = '*'
    ASC = 'c'
    DESC = 'd'
    def __init__(self, size):
        self.__size = size
        self.__values = [self.EMPTY]*(size**2)

    def clear(self, indice):
        self.__values[indice] = self.EMPTY

    def is_full(self):
        return self.EMPTY not in self.__values

    def go_on(self):
        """
        cherche le premier slot vide et le remplit avec croissant
        """
        assert not self.is_full()
        i = self.__values.index(self.EMPTY)
        self.__values[i] = self.ASC
    
    def next(self) -> bool:
        """
        produit la grille suivante : dépile jusqu'à rencontrer un 'c'
        et le change pour 'd'
        renvoie True si succès et False si ça se vide
        """
        i = len(self.__values) - 1
        while i >= 0 and self.__values[i] != self.ASC:
            self.__values[i] = self.EMPTY
            i -= 1
        if i < 0:
            return False
        self.__values[i] = self.DESC
        return True
    
    def __is(self, line:int, col:int, value) -> bool:
        """
        renvoie True si pour ce noeud la valeur est celle indiquée, 0 sinon
        """
        if not 0 <=  line < self.__size:
            return False
        if not 0 <=  col < self.__size:
            return False
        return self.__values[line*self.__size + col] == value
        
    def count(self, line, col) -> int:
        """
        line, col: position d'un noeud donc décalé par rapport à la grille
        """
        return 0 + self.__is(line-1, col-1, self.DESC) + \
                 + self.__is(line-1, col  , self.ASC ) + \
                 + self.__is(line  , col-1, self.ASC ) + \
                 + self.__is(line  , col  , self.DESC)
    
    def empty_neighbours(self, line, col) -> int:
        """
        renvoie le nombre de voisins vide
        """
        return 0 + self.__is(line-1, col-1, self.EMPTY) + \
                 + self.__is(line-1, col  , self.EMPTY) + \
                 + self.__is(line  , col-1, self.EMPTY) + \
                 + self.__is(line  , col  , self.EMPTY)
    
    def has_cycle(self) -> bool:
        g = Graph()
        s = self.__size + 1
        for i in range(s**2):
            line = i//s
            col = i%s
            g.add_node((line, col))
        for i in range(s**2):
            line = i//s
            col = i%s
            if self.__is(line-1, col, self.ASC):
                g.add_vertex((line,col), (line-1,col+1))
            if self.__is(line, col, self.DESC):
                g.add_vertex((line,col), (line+1,col+1))
        return g.has_cycle()

    def tex(self):
        lines = [",".join(self.__values[i:i+self.__size]) for i in range(0,self.__size**2, self.__size)]
        return "\n".join([
            "\slant{"+str(self.__size)+"}{ {%",
            ",%\n".join(lines)+',%',
            "} } { black }"
        ])
    
    def __str__(self):
        return "".join(self.__values)


class Slant:
    def __init__(self, size:int, values:list):
        """
        size: nombe de lignes et cols de la grille
              les nœuds sont donc en nombre size+1 x size+1
        values: tableau contenant None ou une étiquette pour mettre un nœud
        """
        self.__grid_size = size
        self.__node_size = size + 1
        self.__node_number = self.__node_size**2
        assert self.__node_number >= len(values)

        self.__values = [None]*self.__node_number
        for i, item in enumerate(values):
            self.__values[i] = item
    
    @classmethod
    def make_from_id(cls, game_id:str):
        """
        game_id: chaine contenant l'id générée par les jeux de simon tatham
        renvoie un objet Slant
        """
        size, vals = game_id.split(':')
        slines, scols = size.split('x')
        lines = int(slines)
        cols = int(scols)
        assert lines == cols
        values = []
        for letter in vals:
            if letter in "01234":
                values.append(int(letter))
                continue
            j = ord(letter) - ord('a') + 1
            values += [None]*j
        return Slant(lines, values)
    
    def __get_min_max(self, soluce:SoluceSlant, line, col) -> int:
        """
        pour une grille soluce envisagée, en une position line, col,
        indique le nombre min et max de traits entrants
        """
        c = soluce.count(line, col)
        e = soluce.empty_neighbours(line, col)
        return c, c+e
    
    def __test_count(self, soluce:SoluceSlant) -> bool:
        for i, item in enumerate(self.__values):
            if item is None:
                continue
            line = i//self.__node_size
            col = i%self.__node_size
            m, M = self.__get_min_max(soluce, line, col)
            if not m <= item <= M:
                return False
        return True
    

    def __test(self, soluce:SoluceSlant) -> bool:
        """
        soluce: grille contenant 'd' pour décroissant, 'c' pour croissant, ' ' pour rien
        renvoie True si la grille soluce est valide
        """
        if not self.__test_count(soluce):
            return False
        return not soluce.has_cycle()

    def get_sol(self):
        soluce = SoluceSlant(self.__grid_size)
        while not soluce.is_full():
            if self.__test(soluce):
                soluce.go_on()
                continue
            success = soluce.next()
            if not success:
                break
        return soluce

    def __tex_grid(self):
        """
        renvoie la grille elle-même en tex
        """
        svalues = list(map(
           lambda item:' ' if item is None else str(item),
           self.__values
        ))
        lines = [",".join(svalues[i:i+self.__node_size]) for i in range(0, self.__node_number, self.__node_size)]
        return "\islands{" + str(self.__node_size) + "}{{%\n" + \
               ',%\n'.join(lines) + "%\n"           + \
               "}}{.3}{1}"

    def tex(self):
        """
        renvoie la version tex
        """
        soluce = self.get_sol()
        return "\n".join([
            "\\begin{tikzpicture}[scale=1]",
            "\\dottedGrid{" + str(self.__grid_size) + "}",
            "\\ifthenelse{\\showCor = 1}{",
            soluce.tex(),
            "}{ }",
            self.__tex_grid(),
            "\\end{tikzpicture}",
        ])
    
if __name__ == '__main__':
    game_id = input("id = ")
    #"11x11:d1d11a1a2b2123a11a3a231a21d3c23a211b1b32a133a1a123a3e1a223d312f131a1c132b1c2a11d233a1b23a3a3a2b1d1d11a"
    s = Slant.make_from_id(game_id)
    print(s.tex())
