"""
Dessine les cages
"""

from typing import Dict, Tuple, Optional

from modules.primitives.cellgroup import CellGroup

class Cages:
    __zones:Tuple[CellGroup]
    __address_to_zone:Dict[Tuple[int,int],CellGroup]
    __height:int
    __width:int
    def __init__(self, zones:str):
        self.__address_to_zone = {}
        lines = [line.strip() for line in zones.split('\n')]
        lines = [line for line in lines if line != '']
        zones:Dict[str,CellGroup] = {}
        self.__height = len(lines)
        self.__width = max(len(line) for line in lines)
        for iline_from_top, line in enumerate(lines):
            iline = self.__height-iline_from_top-1
            assert len(line) == self.__width
            for icol, letter in enumerate(line):
                if letter not in zones:
                    zones[letter] = CellGroup(letter)
                zones[letter].add_coord(iline, icol)
                self.__address_to_zone[(iline,icol), zones[letter]]
        self.__zones = tuple(zones.values())
        for z in self.__zones:
            z.init_possibles(list(range(1,z.size+1)))




    def tex(self):
        output = [
            "\\draw[dotted] (0,0) rectangle (" + str(self.__width) + ", " + str(self.__height) + ");",
            "\\draw[dotted] (0,0) grid[step=1] (" + str(self.__width) + ", " + str(self.__height) + ");"
        ]
        for z in self.__zones:
            output.append(z.cadre().tex())
        if self.get_sol():
            output.append("\\ifthenelse{\\showCor = 1} {")
            output.append("\\showListRaw{"+str(self.__width)+"}{{")
            str_vals_sol = []
            for iline in range(self.__height):
                for icol in range(self.__width):
                    v = self.__coords_to_val[(iline,icol)]
                    str_vals_sol.append(str(v) if v.known and not v.is_initial else " ")
            lines_vals_sols = ",%\n".join([", ".join(str_vals_sol[i*self.__width:(i+1)*self.__width]) for i in range(self.__height)])
            output.append(lines_vals_sols)
            output.append("}}{1}")
            output.append("}{ }")
        return "%\n".join(output)


if __name__ == '__main__':
    test = '\n'.join([
        'AAAACCC',
        'BAKKCDD',
        'BKKLLDD',
        'BHKLLDE',
        'BHHLFFE',
        'HHGFFFE'
    ])
    t = Cages(test)
    print(t.tex())
