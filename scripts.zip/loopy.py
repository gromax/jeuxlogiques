

from typing import Optional, List, Tuple, Unpack
from graph import Graph

class Fence:
    def __init__(self, *args:Unpack[Tuple[int,int]]):
        n = len(args)
        assert n ==0 or n == 2
        self.__parcours = [] if n == 2 and args[0] == args[1] else list(args)
        self.__state = -1
        self.__locked = False

    def __str__(self):
        if self.off:
            return ' '
        if self.unset:
            return '?'
        if self.empty:
            return '.'
        if len(self.__parcours) != 2:
            return ' -- '.join(str(p) for p in self.__parcours)
        l1, _ = self.__parcours[0]
        l2, _ = self.__parcours[-1]
        if abs(l1-l2) > 0:
            return '|'
        else:
            return '-'

    @classmethod
    def locked_off_fence(cls, *args:Unpack[Tuple[int,int]]):
        f = Fence(*args)
        f.set_off()
        f.lock()
        return f

    def set_off(self):
        assert self.__state ==0 or not self.__locked
        self.__state = 0

    def __add__(self, other:"Fence") -> "Fence":
        assert self.__state == other.__state
        if self.empty:
            return other.clone()
        if other.empty:
            return self.clone()

        f = self.clone()
        if self.__parcours[0] == other.__parcours[0]:
            f.__parcours = reversed(other.__parcours) + self.__parcours
        elif self.__parcours[-1] == other.__parcours[0]:
            f.__parcours += other.__parcours
        elif self.__parcours[0] == other.__parcours[-1]:
            f.__parcours = other.__parcours + self.__parcours
        elif self.__parcours[-1] == other.__parcours[-1]:
            f.__parcours += reversed(other.__parcours)
        else:
            raise ValueError()
        
        f.__consolid()
        return f

    def __consolid(self):
        i = 0
        while i < len(self.__parcours)-2:
            la,ca = self.__parcours[i]
            lb,cb = self.__parcours[i+1]
            lc,cc = self.__parcours[i+2]
            if la == lb == lc or ca == cb == cc:
                self.__parcours.pop(i+1)
            else:
                i += 1

    def clone(self) -> "Fence":
        f = Fence()
        f.__parcours = self.__parcours.copy()
        f.__locked = self.__locked
        f.__state = self.__state
        return f

   
    @property
    def extremities(self) -> List[Tuple[int,int]]:
        if len(self.__parcours) < 2:
            return self.__parcours.copy()
        return [self.__parcours[0], self.__parcours[-1]]
        
    def connected(self, other:"Fence") -> bool:
        if self.empty or other.empty:
            return False
        e1 = self.extremities
        e2 = other.extremities
        return len([a for a in e1 if a in e2]) > 0

    @property
    def is_curl(self) -> bool:
        return self.empty or self.__parcours[0] == self.__parcours[-1]

    @property
    def empty(self) -> bool:
        return len(self.__parcours) == 0

    def lock(self):
        self.__locked = True

    @property
    def on(self) -> bool:
        return self.__state == 1
    
    @property
    def off(self) -> bool:
        return self.__state == 0
    
    @property
    def unset(self) -> bool:
        return self.__state == -1
    
    def next(self) -> bool:
        assert not self.__locked
        self.__state += 1
        if self.__state == 2:
            self.__state = -1
            return False
        return True

class LoopySoluce:
    def __init__(self, size, values):
        self.__fence_off = Fence.locked_off_fence()
        self.__size = size
        self.__fences:list[Fence] = []
        self.__vert_offset = (size+1)*size
        self.__values = values
        for iline in range(self.__size+1):
            for icol in range(self.__size):
                f = Fence((iline,icol), (iline,icol+1))
                self.__fences.append(f)
        for iline in range(self.__size):
            for icol in range(self.__size+1):
                f = Fence((iline,icol), (iline+1,icol))
                self.__fences.append(f)
        self.__success = self.__get_sol()
        
    def get_fence_up(self, iline, icol) -> Fence:
        if not (0 <= iline <= self.__size and 0 <= icol < self.__size):
            return self.__fence_off
        return self.__fences[iline*self.__size + icol]
    
    def get_fence_down(self, iline, icol) -> Fence:
        if not (-1 <= iline < self.__size and 0 <= icol < self.__size):
            return self.__fence_off
        return self.__fences[(iline+1)*self.__size + icol]
    
    def get_fence_left(self, iline, icol) -> Fence:
        if not (0 <= iline < self.__size and 0 <= icol <= self.__size):
            return self.__fence_off
        return self.__fences[iline*self.__size + icol + self.__vert_offset]

    def get_fence_right(self, iline, icol) -> Fence:
        if not (0 <= iline < self.__size and -1 <= icol < self.__size):
            return self.__fence_off
        return self.__fences[iline*self.__size + icol + 1 + self.__vert_offset]

    def __nodes_ok(self) -> bool:
        """
        renvoie True si tous les nœuds ont possiblement 0 ou 2 connexions
        """
        for icol in range(self.__size+1):
            for iline in range(self.__size+1):
                fences = [
                    self.get_fence_up(iline-1, icol-1),
                    self.get_fence_right(iline-1, icol-1),
                    self.get_fence_down(iline, icol),
                    self.get_fence_left(iline, icol)
                ]
                on_f = sum(f.on for f in fences)
                unset_f = sum(f.unset for f in fences)
                if on_f > 2 or on_f == 1 and unset_f == 0:
                    return False
        return True
    
    def __has_one_curl(self) -> True:
        fences_on = [f for f in self.__fences if f.on]
        if len(fences_on) == 0:
            return True
        f = fences_on.pop()
        while not f.empty and (i:=self.__get_connected(f)) >= 0:
            g = fences_on.pop(i)
            f = f + g
        if len(fences_on) > 0:
            return False
        return f.empty

    def __get_connected(self, f:Fence, fences:list[Fence]) -> int:
        for i, g in enumerate(fences):
            if f.connected(g):
                return i
        return -1

    def __isfull(self) -> bool:
        for f in self.__fences:
            if f.unset:
                return False
        return True

    def __value_ok(self, iline:int, icol:int, value:int) -> bool:
        if value == -1:
            return True
        fences = [
            self.get_fence_up(iline, icol),
            self.get_fence_down(iline, icol),
            self.get_fence_left(iline, icol),
            self.get_fence_right(iline, icol)
        ]
        count_on = sum(f.on for f in fences)
        count_unset = sum(f.unset for f in fences)
        return count_on <= value <= count_on + count_unset

    def __values_ok(self) -> bool:
        for i, value in enumerate(self.__values):
            iline = i//self.__size
            icol = i%self.__size
            if not self.__value_ok(iline, icol, value):
                return False
        return True

    def __str__(self):
        out = []
        for i in range(self.__size):
            out.append("+" + "+".join(str(self.get_fence_up(i,j)) for j in range(self.__size)) + "+")
            out.append(" ".join(str(self.get_fence_right(i,j)) for j in range(-1,self.__size)))
        out.append("+" + "+".join(str(self.get_fence_down(self.__size-1,j)) for j in range(self.__size)) + "+")
        return '\n'.join(out)

    def __is_ok(self) -> bool:
        return self.__nodes_ok() and self.__values_ok() and (not self.__isfull() or self.__has_one_curl())

    def __get_sol(self) -> bool:
        n = len(self.__fences)
        if n == 0:
            return
        cursor = 0
        while 0 <= cursor < n:
            if not self.__fences[cursor].next():
                cursor -= 1
                continue
            if self.__is_ok():
                cursor += 1
        return cursor != -1

    def tex(self) -> str:
        fences_on = [f for f in self.__fences if f.on and not f.empty]
        output = []
        while fences_on != []:
            f = fences_on.pop()
            i = self.__get_connected(f, fences_on)
            if i == -1:
                output.append("\\draw " + str(f) + ";")
            else:
                f = f + fences_on.pop(i)
        return "\n".join(output)
    
    @property
    def success(self) -> bool:
        self.__success
  




class Loopy:
    def __init__(self, size:int, values:list):
        """
        size: nombe de lignes et cols de la grille
              les nœuds sont donc en nombre size+1 x size+1
        values: tableau contenant None ou une étiquette pour mettre un nœud
        """
        self.__size = size
        assert self.__size**2 >= len(values)

        self.__values = [-1]*(self.__size**2)
        for i, item in enumerate(values):
            self.__values[i] = item
    
    @classmethod
    def make_from_id(cls, game_id:str):
        """
        game_id: chaine contenant l'id générée par les jeux de simon tatham
        renvoie un objet Slant
        """
        size, vals = game_id.split(':')
        slines, _ = size.split('x')
        size = int(slines)
        values = []
        for letter in vals:
            if letter in "01234":
                values.append(int(letter))
                continue
            j = ord(letter) - ord('a') + 1
            values += [-1]*j
        # lignes remises à l'endroit
        lines = [values[i:i+size] for i in range(0,size**2, size)]
        return Loopy(size, sum(lines[::-1], []))
    
    def get_value(self, iline:int, icol:int) -> int:
        if not 0 <= iline < self.__size:
            return -1
        if not 0 <= icol < self.__size:
            return -1
        return self.__values[self.__size*iline + icol]

    def __tex_grid(self):
        """
        renvoie la grille elle-même en tex
        """
        svalues = list(map(
           lambda item:' ' if item == -1 else str(item),
           self.__values
        ))
        lines = [",".join(svalues[i:i+self.__size]) for i in range(0, len(self.__values), self.__size)]
        return "\\showList{" + str(self.__size) + "}{ {\n" + \
               ',\n'.join(lines) + "\n"                     + \
               "} }{1.5}"
    
    def tex(self):
        """
        renvoie la version tex
        """
        soluce = LoopySoluce(self.__size, self.__values)
        return "\n".join([
            "\\begin{tikzpicture}[scale=1]",
            "\\dottedGrid{" + str(self.__grid_size) + "}",
            self.__tex_grid(),
            "\\ifthenelse{\\showCor = 1}{",
            soluce.tex(),
            "}{ }"
        ])
    
if __name__ == '__main__':
    f1 = Fence((0,0), (1,0))
    f2 = Fence((1,0), (2,0))
    f3 = Fence((2,0), (2,1))
    assert str(f1) == '?'
    f1.next()
    assert str(f1) == ' '
    f1.next()
    assert str(f1) == '|'
    f2.next()
    f2.next()
    f3.next()
    f3.next()
    assert str(f3) == '-'
    assert f1.connected(f2)
    assert f2.connected(f3)
    assert not f1.connected(f3)
    



    game_id = input("id = ") #"7x7t0:a22d3c1b3022a3c3a2b02b2b1b31a1d2b"
    s = Loopy.make_from_id(game_id)
    print(s.tex())
