class Coord:
    def __init__(self, iline:int, icol:int):
        self.__iline = iline
        self.__icol = icol
    
    def __str__(self):
        return f"({self.x},{self.y})"
    
    @property
    def x(self):
        return self.__icol
    
    @property
    def y(self):
        return self.__iline
    
    def __eq__(self, other:"Coord") -> bool:
        return self.__iline == other.__iline and self.__icol == other.__icol
    

if __name__ == '__main__':
    c = Coord(4,5)
    assert str(c) == "(5,4)"
    d = Coord(4,5)
    assert c == d