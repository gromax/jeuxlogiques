from typing import Dict, Tuple, Optional

from zone import Zone
from value import Value

class Techtonic:
    def __init__(self, zones:str, values:str):
        lines = [line.strip() for line in zones.split('\n')]
        lines = [line for line in lines if line != '']
        zones:Dict[str,Zone] = {}
        self.__height = len(lines)
        self.__width = max(len(line) for line in lines)
        self.__values_to_tell:list[Value] = []
        self.__coords_to_val:Dict[Tuple[int,int],Value] = {}
        values = "".join(values.split("\n"))
        for i, letter in enumerate(values):
            iline = self.__height-i//self.__width-1 
            icol = i % self.__width
            if letter.isdigit():
                self.__coords_to_val[(iline, icol)] = Value(int(letter))
            else:
                v = Value(-1)
                self.__values_to_tell.append(v)
                self.__coords_to_val[(iline, icol)] = v
        
        for iline_rev, line in enumerate(lines):
            iline = self.__height-iline_rev-1
            assert len(line) == self.__width
            for icol, letter in enumerate(line):
                if letter not in zones:
                    zones[letter] = Zone(letter)
                value = self.__coords_to_val[(iline,icol)]
                zones[letter].add_coord(iline, icol, value)
        self.__zones:list[Zone] = list(zones.values())
        for z in self.__zones:
            z.init_possibles(list(range(1,z.size+1)))
        
    def __get_value(self, iline, icol) -> Optional[Value]:
        return self.__coords_to_val.get((iline, icol), None)

    def __get_voisines(self, iline, icol) -> list[int]:
        delta = [(-1,-1), (-1,0), (-1,1),
                 ( 0,-1),         ( 0,1),
                 ( 1,-1), ( 1,0), ( 1,1)]
        vals = [self.__get_value(iline+dl, icol+dc) for dl, dc in delta]
        return [item.value for item in vals if item is not None and item.known]

    def __voisinage_ok(self, iline, icol) -> bool:
        v = self.__get_value(iline, icol)
        if v is None or not v.known:
            return True
        return v.value not in self.__get_voisines(iline, icol)

    def voisinages_ok(self) -> bool:
        for iline in range(self.__height):
            for icol in range(self.__width):
                if not self.__voisinage_ok(iline, icol):
                    return False
        return True
    
    def zones_ok(self) -> bool:
        for z in self.__zones:
            if z.has_double():
                return False
        return True
    
    def is_ok(self) -> bool:
        return self.zones_ok() and self.voisinages_ok()

    def get_sol(self) -> bool:
        n = len(self.__values_to_tell) 
        if n == 0:
            return True
        icurrent = 0
        while icurrent >= 0 and icurrent < n:
            test = self.__values_to_tell[icurrent].next()
            if not test:
                icurrent -= 1
                continue
            if self.is_ok():
                icurrent += 1
        return icurrent >= 0

    def tex(self):
        output = [
            "\\draw[dotted] (0,0) rectangle (" + str(self.__width) + ", " + str(self.__height) + ");",
            "\\draw[dotted] (0,0) grid[step=1] (" + str(self.__width) + ", " + str(self.__height) + ");"
        ]
        for z in self.__zones:
            output.append(z.cadre().tex())
        vals = sum((z.values() for z in self.__zones), [])
        output.append("\\begin{scope}[shift={(.5,.5)}]")
        output.append("  \\foreach \\x/\\y/\\v in {"+", ".join(vals)+"} {\\draw (\\x,\\y) node[scale=2]{\\v};}")
        output.append("\\end{scope}")
        if self.get_sol():
            output.append("\\ifthenelse{\\showCor = 1} {")
            output.append("\\showListRaw{"+str(self.__width)+"}{{")
            str_vals_sol = []
            for iline in range(self.__height):
                for icol in range(self.__width):
                    v = self.__coords_to_val[(iline,icol)]
                    str_vals_sol.append(str(v) if v.known and not v.is_initial else " ")
            lines_vals_sols = ",%\n".join([", ".join(str_vals_sol[i*self.__width:(i+1)*self.__width]) for i in range(self.__height)])
            output.append(lines_vals_sols)
            output.append("}}{1}")
            output.append("}{ }")
        return "%\n".join(output)


if __name__ == '__main__':
    test = '\n'.join([
        'AAAACCC',
        'BAKKCDD',
        'BKKLLDD',
        'BHKLLDE',
        'BHHLFFE',
        'HHGFFFE'
    ])
    vals = '\n'.join([
        'xxx2x2x',
        'xxxxxxx',
        '2xxxxxx',
        'xxxx5xx',
        'xxxxxxx',
        'xxx2xx1'    ])
    t = Techtonic(test, vals)
    print(t.tex())
