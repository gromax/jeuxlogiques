from coord import Coord

class Segment:
    def __init__(self, p1:Coord, p2:Coord):
        self.__points = [p1, p2]
    
    def __getitem__(self, key):
        return self.__points[key]
    
    def __eq__(self, other:"Segment") -> bool:
        return self.__points == other.__points
    
    @property
    def end(self):
        return self.__points[1]
    
    @property
    def start(self):
        return self.__points[0]
    
    def is_after(self, other:"Segment") -> bool:
        return self.start == other.end
    
    def is_inline(self, other:"Segment") -> bool:
        if not self.is_after(other):
            return False
        return other.end.x == other.start.x == self.end.x or \
               other.end.y == other.start.y == self.end.y
    
    def opposite(self):
        p1, p2 = self.__points
        return Segment(p2, p1)
    
    def __str__(self):
        p1, p2 = self.__points
        return f"{p1} -- {p2}"
    
if __name__ == '__main__':
    a = Coord(4,5)
    b = Coord(4,6)
    c = Coord(4,7)
    d = Coord(2,8)
    assert Segment(a, b) == Segment(a, b)
    assert Segment(a,b) != Segment(c,d)
    assert Segment(a,b).start == a
    assert Segment(a,b).end == b
    assert Segment(a,b).is_after(Segment(c,a))
    assert not Segment(a,b).is_after(Segment(c,d))
    assert Segment(b,c).is_inline(Segment(a,b))
    assert not Segment(b,c).is_inline(Segment(d,b))