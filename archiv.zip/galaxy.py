from typing import List, Tuple, Optional, Set, Dict

from modules.primitives.cellgroup import CellGroup
from modules.primitives.cell import Cell

class Star:
    __candidates = Set[Tuple[int,int]]
    def __init__(self, line:int, col:int, index:int):
        self.__line = line
        self.__col = col
        self.__index = index
        self.__candidates = set()
    
    @property
    def iline(self) -> int:
        return self.__line

    @property
    def icol(self) -> int:
        return self.__col
    
    @property
    def lines(self) -> List[int]:
        return [self.__line//2] if self.__line%2 == 0 else [self.__line//2, self.__line//2+1]

    @property
    def cols(self) -> List[int]:
        return [self.__col//2] if self.__col%2 == 0 else [self.__col//2, self.__col//2+1]

    @property
    def index(self) -> int:
        return self.__index
    
    def add_candidate(self, cell:Cell):
        self.__candidates.add(cell.pos)
    
    def remove_candidate(self, cell:Cell):
        self.__candidates.discard(cell.pos)
    
    def clear_candidates(self):
        self.__candidates = set()

    def symetrize_candidates(self):
        """
        vérifie la symétrie
        """
        symetrized = set()
        for coord in self.__candidates:
            if self.sym(coord) in self.__candidates:
                symetrized.add(coord)
        self.__candidates = symetrized

    def sym(self, coord:Tuple[int,int]) -> Tuple[int,int]:
        """
        calcul le symétrique par rapport à l'étoile
        """
        return self.iline - coord[0], self.icol - coord[1]

    @property
    def candidates(self) -> List[Cell]:
        return self.__candidates

class Historic:
    """
    garde la mémoire d'un pas de recherche
    """
    __cell:Cell
    __force:bool
    __iStar:int
    __candidates:Set[int]
    __reversed:bool

    def __init__(self, cell:Cell, iStar:int, force:bool):
        """
        Une opération simple consiste à supprimer un candidat
        sinon, c'est un forçage
        """
        self.__cell = cell
        self.__candidates = cell.candidates
        self.__force = force
        self.__iStar = iStar
        self.__reversed = False
        if force:
            cell.value = iStar
        else:
            cell.remove_candidate(iStar)

    @property
    def is_force(self) -> bool:
        return self.__force
    
    @property
    def cell(self) -> Cell:
        return self.__cell

    @property
    def iStar(self) -> int:
        return self.__iStar

    @classmethod
    def force_star(cls, cell:Cell, iStar:int) -> "Historic":
        return Historic(cell, iStar, True)
    
    @classmethod
    def remove_star_candidate(cls, cell:Cell, iStar:int) -> "Historic":
        return Historic(cell, iStar, False)
    
    def reverse(self):
        if self.__reversed:
            return
        self.__reversed = True
        self.__cell.reinit(self.__candidates)

    def tosub(self):
        assert self.__force
        self.reverse()
        self.__force = False
        self.__cell.remove_candidate(self.__iStar)
        self.__reversed = False

    def __str__(self)->str:
        if self.__force:
            return f"{self.__cell.pos} forcé à Star {self.__iStar}"
        else:
            return f"{self.__cell.pos} suppression candidat Star {self.__iStar}"


class Galaxy:
    __game_id:str
    __cells:CellGroup
    __size:int
    __stars:List[Star]
    __stack = List[Historic]

    def __init__(self, game_id:str):
        """
        game_id: chaîne selon jeu loopy de simon tatham
        ex: 7x7t0:a22d3c1b3022a3c3a2b02b2b1b31a1d2b
        """
        sizeStr, contentStr = game_id.split(':')
        self.__size = int(sizeStr.split("x")[0]) # assume que ce sera un carré
        self.__cells = CellGroup.make_from_size("cells", self.__size)
        self.__game_id = game_id

        values = [ord(letter) - ord('a') + 1 for letter in contentStr]
        t = -1
        S = 2*self.__size - 1
        stars_pos = []
        for v in values:
            t += v
            if v == 26:
                # un z sert à faire un saut plus grand
                # exemple zc pour 28
                t -= 1
                continue
            stars_pos.append((t//S, t%S))
        self.__stars = [Star(line, col, i) for i, (line, col) in enumerate(stars_pos)] 

    def __get_neighbours(self, iline:int, icol:int) -> List[Cell]:
        coords = self.__get_neighbours_coords(iline, icol)
        return [self.__cells[line,col] for line,col in coords]

    def __get_neighbours_coords(self, iline:int, icol:int) -> List[Tuple[int,int]]:
        deltas = ((-1,0), (1,0), (0,-1), (0,1))
        return [(iline+dline,icol+dcol) for dline,dcol in deltas if self.__cells.has(iline+dline, icol+dcol)]

    def __lock_contact_stars(self):
        """
        verrouille les cellules en contacte avec une étoile sur cette étoile
        """
        for s in self.__stars:
            lines = [s.iline//2] if s.iline%2 == 0 else [s.iline//2, s.iline//2+1]
            cols = [s.icol//2] if s.icol%2 == 0 else [s.icol//2, s.icol//2+1]
            for li in lines:
                for co in cols:
                    self.__cells[li,co].set_initial(s.index)

    def __get_star_candidates(self, iStar:int):
        """
        attribue les cellules candidates d'une étoile en se propageant
        à partir des cellules attribuées à cette étoile
        """
        star = self.__stars[iStar]
        star.clear_candidates()
        vus = set()
        stack = self.__cells.cells(filter=lambda c:c.value == iStar)
        while stack != []:
            c = stack.pop()
            if c.pos in vus:
                continue
            vus.add(c.pos)
            if c.value == -1 and c.has(iStar):
                star.add_candidate(c)
            n = self.__get_neighbours(c.iline, c.icol)
            stack = stack + n
        star.symetrize_candidates()

    def __refresh_iStar_candidates(self, iStar:int):
        """
        recherche les cellules atteignable de puis une étoile et retire
        le candidat iStar des autres
        """
        self.__get_star_candidates(iStar)
        star_candidates = self.__stars[iStar].candidates
        for c in self.__cells.cells(filter=lambda c:c.value == -1):
            if c.has(iStar) and c.pos not in star_candidates:
                self.__stack.append(Historic.remove_star_candidate(c, iStar))
                # si cette cellule n'a plus qu'un candidat, il faut le reporter
                self.__sym_when_only_one_candidate(c)

    def __sym_when_only_one_candidate(self, cell:Cell):
        """
        si cell n'a plus qu'un candidat, ajuste la cellule symétrique
        """
        iStar = cell.value
        if iStar == -1:
            return
        star = self.__stars[iStar]

        sym_iline, sym_icol = star.sym(cell.pos)
        if not self.__cells.has(sym_iline, sym_icol):
            # peut arriver dans un cas où une cellule va se retrouver sans possibilité
            # et que l'on supprime l'avant dernière
            # alors on traite la dernière comme si c'était la bonne mais elle n'est en fait pas valide
            self.__stack.append(Historic.remove_star_candidate(cell, iStar))
            return
        cSym = self.__cells[sym_iline, sym_icol]
        for candidate in cSym.candidates:
            if candidate != iStar:
                self.__stack.append(Historic.remove_star_candidate(cSym, candidate))

    def __destack(self) -> bool:
        """
        dépile à la recherche d'un forcé
        renvoie False si pas de forcé trouvé
        """
        while self.__stack != [] and not self.__stack[-1].is_force:
            self.__stack.pop().reverse()
        if self.__stack == []:
            # pas faisable
            return False
        self.__stack[-1].tosub()
        self.__sym_when_only_one_candidate(self.__stack[-1].cell)
        return True

    def __text_conexity(self) -> bool:
        # en forçant, on peut aboutir à des solutions non connexes
        for iStar in range(len(self.__stars)):
            if not self.__cells.subGroup(lambda c:c.value==iStar).is_connexe():
                return False
        return True

    def solution(self) -> bool:
        """
        Cherche une solution. envoie True si elle est trouvée
        """
        self.__stack:List[Historic] = []
        self.__lock_contact_stars()
        self.__cells.init_candidates(list(range(0,len(self.__stars))))
        nStars = len(self.__stars)
        while True:
            stackLen = len(self.__stack)
            for iStar in range(nStars):
                self.__refresh_iStar_candidates(iStar)
            if self.__cells.hasNoValueCell():
                # nous avons dû faire un forçage faut
                # il faut reculer
                if self.__destack():
                    continue
                else:
                    return False
            unknowns = self.__cells.cells(filter=lambda c:c.value == -1)
            if len(unknowns) == 0:
                if self.__text_conexity():
                    return True
                # il faut déstack
                if self.__destack():
                    continue
                else:
                    return False
            if len(self.__stack) == stackLen:
                # on n'a pas progressé dans le tri des candidats.
                # il faut tenter un forçage
                cell = unknowns[0]
                candidate = next(iter(cell.candidates))
                self.__stack.append(Historic.force_star(cell, candidate))
                self.__sym_when_only_one_candidate(cell)

    def tex(self) -> str:
        """
        Retourne le code LaTeX pour générer le jeu
        """
        output = ["%id: "+self.__game_id]
        output.append("\\begin{tikzpicture}[scale=.7]")
        output.append("\\draw[line width=0.5pt] (0,0) grid[step=1] ("+str(self.__size)+","+str(self.__size)+");")
        output.append("\\begin{scope}[shift={(0,"+str(self.__size)+")}, yscale=-1]")
        output.append("\\foreach \\x/\\y in {"+",".join(f"{s.icol/2+.5}/{s.iline/2+.5}" for s in self.__stars)+"} \\draw[fill=white] (\\x,\\y) circle(0.3);")
        if self.solution():
            for s in self.__stars:
                cadre = self.__cells.subGroup(filter=lambda c:c.value == s.index).cadre()
                output.append(cadre.tex())
        output.append("\\end{scope}")
        output.append("\\end{tikzpicture}")
        return "%\n".join(output)

