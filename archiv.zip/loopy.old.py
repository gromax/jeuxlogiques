from typing import List

from modules.jeux.archiv.game import Game
from modules.primitives.cellgroup import CellGroup
from modules.primitives.cell import Cell

class Loopy(Game):
    __size:int
    __values:List[int]

    def __init_cells_content(self, contentStr:str):
        """
        initialise les cellules selon le code fournit
        ex: a22d3c1b3022a3c3a2b02b2b1b31a1d2b signifie que l'on saute 1 case puis 2 puis 2 puis saute 4 cases (d)...
        """
        self.__values = [-1]*(self.__size**2)
        if contentStr == "":
            return
        i = 0
        for car in contentStr:
            if car in "01234":
                # c'est un digit à placer
                self.__values[i] = int(car)
                i += 1
                continue
            delta = ord(car) - ord('a') + 1
            i += delta

    def __init__(self, game_id:str):
        """
        game_id: chaîne selon jeu loopy de simon tatham
        ex: 7x7t0:a22d3c1b3022a3c3a2b02b2b1b31a1d2b
        """
        sizeStr, contentStr = game_id.split(':')
        self.__size = int(sizeStr.split("x")[0]) # assume que ce sera un carré
        cells = CellGroup.make_from_size("cells", self.__size, default=Cell(-1,-1,0)) # cellule hors cadre est extérieur
        super().__init__(cells, game_id)
        self.__init_cells_content(contentStr)

    def candidates(self):
        return [0,1] # 0 pour out, 1 pour in

    def _to_update(self):
        return []

    def _valid(self) -> bool:
        """
        renvoie True si les inégalités sont respectées, False sinon
        """
        if self._cells.hasNoValueCell():
            return False
        for iline in range(self.__size):
            for icol in range(self.__size):
                c = self._cells[iline,icol]
                if c.value == -1:
                    continue
                constraint = self.__values[iline*self.__size + icol]
                if constraint == -1:
                    continue
                unknowns = 0
                walls = 0
                for dline, dcol in [(-1,0), (1,0), (0,-1), (0,1)]:
                    neighbour = self._cells[iline+dline, icol+dcol].value
                    if neighbour == -1:
                        unknowns += 1
                    elif neighbour != c.value:
                        walls += 1
                if not walls <= constraint <= walls + unknowns:
                    return False
        if not self.is_full():
            return True
        # vérifier connexité des intérieurs
        interior = self._cells.subGroup(filter=lambda c:c.value == 1)
        return interior.is_connexe()

    def tex(self) -> str:
        """
        Retourne le code LaTeX pour générer le jeu
        """
        output = ["%id: "+self._game_id]
        output.append("\\begin{tikzpicture}[scale=.7]")
        output.append("\\draw[line width=0.5pt] (0,0) grid[step=1] ("+str(self.__size)+","+str(self.__size)+");")
        vals = list(map(lambda d:str(d) if d>=0 else ' ', self.__values))
        strVals = ",%\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
        output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
        output.append(strVals)
        output.append("} }{1.5}")

        if self.solution():
            interior = self._cells.subGroup(filter=lambda c:c.value == 1)
            cadre = interior.cadre()
            output.append("\\begin{scope}[shift={(0,"+str(self.__size)+")}, yscale=-1]")
            output.append(cadre.tex())
            output.append("\\end{scope}")
        output.append("\\end{tikzpicture}")
        return "%\n".join(output)

