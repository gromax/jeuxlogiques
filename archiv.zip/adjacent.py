from typing import List
from modules.jeux.archiv.game import Game
from modules.primitives.cellgroup import CellGroup
from modules.jeux.unequal import TagCell
from modules.primitives.cell import Cell

class Adjacent(Game):
    """
    Grille de jeu pour unequal
    """
    __values:List[TagCell]
    __size:int
    __lines:List[CellGroup]
    __cols:List[CellGroup]
    __to_update: List[CellGroup]

    def __init__(self, game_id:str):
        """
        game_id: chaîne selon jeu keen de simon tatham
        """
        sizeStr, valuesStr = game_id.split('a:')
        self.__size = int(sizeStr)
        cells = CellGroup.make_from_size("cells", self.__size, default=Cell(-1,-1))
        super().__init__(cells, game_id)

        valuesStrList = valuesStr.split(',')[:self.__size**2]
        self.__values = [TagCell(i//self.__size, i%self.__size, v) for i, v in enumerate(valuesStrList)]
        self.__lines = [CellGroup(f"line {i}") for i in range(self.__size)]
        self.__cols = [CellGroup(f"col {i}") for i in range(self.__size)]
        self.__to_update = self.__lines + self.__cols

        for v in self.__values:
            cell = self._cells[v.line, v.col]
            if v.value > 0:
                cell.set_initial(v.value)
            self.__lines[v.line].add_coord(v.line, v.col, cell)
            self.__cols[v.col].add_coord(v.line, v.col, cell)

    def candidates(self):
        return list(range(1, self.__size+1))

    def _to_update(self):
        return self.__to_update

    def _valid(self) -> bool:
        """
        renvoie True si les inégalités sont respectées, False sinon
        """
        if self._cells.hasNoValueCell():
            return False
        if any(z.has_double() for z in self.__to_update):
            return False
        for v in self.__values:
            iline = v.line
            icol = v.col
            cell = self._cells[iline,icol]
            if not cell.known:
                continue
            currentVal = cell.value
            upVal = self._cells[iline-1,icol].value
            if upVal != -1 and v.up != (abs(upVal-currentVal) == 1):
                return False
            downVal = self._cells[iline+1,icol].value
            if downVal != -1 and v.down != (abs(downVal-currentVal) == 1):
                return False
            leftVal = self._cells[iline,icol-1].value
            if leftVal !=-1 and v.left != (abs(leftVal-currentVal) == 1):
                return False
            rightVal = self._cells[iline,icol+1].value
            if rightVal != -1 and v.right != (abs(rightVal-currentVal) == 1):
                return False
        return True

    def tex(self) -> str:
        """
        Retourne le code LaTeX pour générer le jeu
        """
        output = ["%id: "+self._game_id]
        output.append("\\begin{tikzpicture}[scale=1.5]")
        output.append("\\inequalGrid{"+str(self.__size)+"}")
        ineqSymbols = ", ".join(sum([v.texcoords(lexicographic = True) for v in self.__values], []))
        output.append("\\begin{scope}[shift={(0.5,"+str(self.__size-0.5)+")}, yscale=-1]")
        output.append("  \\foreach \\x/\\y/\\r in {"+ineqSymbols+"} {")
        output.append("    \\begin{scope}[shift={(\\x,\\y)}, rotate=\\r] \\draw[line width=4pt, black!50!white] (.5,-.3) --++ (0,.6);\\end{scope}")
        output.append("  }")
        output.append("\\end{scope}")
        vals = [str(v.value) if v.value > 0 else " " for v in self.__values]
        strVals = ",%\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
        output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
        output.append(strVals)
        output.append("} }{1.5}")

        if self.solution():
            vals = list(map(str, self._cells.ordered_values()))
            strVals = ",\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
            output.append("\\ifthenelse{\\showCor = 1}{")
            output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
            output.append(strVals)
            output.append("} }{1.5}")
            output.append("}{ }")

        output.append("\\end{tikzpicture}")
        return "%\n".join(output)

