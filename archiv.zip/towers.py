from typing import List

from modules.jeux.archiv.game import Game
from modules.primitives.cellgroup import CellGroup

class Towers(Game):
    __size:int
    __lines:List[CellGroup]
    __cols:List[CellGroup]
    __to_update: List[CellGroup]
    __borders: List[int] # parcourus HBGD

    def __init_cells_content(self, contentStr:str):
        """
        initialise les cellules selon le code fournit
        ex: d3c1t2f signifie que l'on saute 4 cases (d) puis on place 3, puis saute 3 (c), etc.
        """
        if contentStr == "":
            return
        i = 0
        for car in contentStr:
            if car in "0123456789":
                # c'est un digit à placer
                d = int(car)
                iline = i//self.__size
                icol = i%self.__size
                self._cells[iline, icol].set_initial(d)
                i += 1
                continue
            if car == '_':
                continue
            delta = ord(car) - ord('a') + 1
            i += delta

    def __init__(self, game_id:str):
        """
        game_id: chaîne selon jeu towers de simon tatham
        """
        sizeStr, contentStr = game_id.split(':')
        self.__size = int(sizeStr)
        cells = CellGroup.make_from_size("cells", self.__size)
        super().__init__(cells, game_id)
        if "," in contentStr:
            bordersStr, cellsContentStr = contentStr.split(',')
        else:
            bordersStr = contentStr
            cellsContentStr = ""
        self.__borders = [int(v) if v != '' else -1 for v in bordersStr.split('/')]
        self.__init_cells_content(cellsContentStr)

        self.__lines = [self._cells[i,:] for i in range(self.__size)]
        self.__cols = [self._cells[:,i] for i in range(self.__size)]
        self.__to_update = self.__lines + self.__cols

    def candidates(self):
        return list(range(1, self.__size+1))

    def _to_update(self):
        return self.__to_update

    def _valid(self) -> bool:
        """
        renvoie True si les inégalités sont respectées, False sinon
        """
        if self._cells.hasNoValueCell():
            return False
        if any(z.has_double() for z in self.__to_update):
            return False
        for i, b in enumerate(self.__borders):
            if b == -1:
                continue
            # il faut récupérer les valeurs
            side = i//self.__size
            index = i%self.__size
            if side == 0:
                # Haut
                cells = self._cells.cells(key=(slice(None),index))
            elif side == 1:
                # Bas
                cells = self._cells.cells(key=(slice(None,None,-1),index))
            elif side == 2:
                # gauche
                cells = self._cells.cells(key=(index,slice(None)))
            else:
                # droite
                cells = self._cells.cells(key=(index,slice(None,None,-1)))
            M = 0
            visibles = 0
            unknowns = False
            for c in cells:
                v = c.value
                if v == -1:
                    unknowns = True
                    break
                elif v>M:
                    M=v
                    visibles += 1
            if not unknowns and visibles != b:
                return False
        return True

    def tex(self) -> str:
        """
        Retourne le code LaTeX pour générer le jeu
        """
        S = self.__size
        str_borders_1 = [str(b) if b!=-1 else "" for b in self.__borders]
        str_borders_2 = ["{"+",".join(str_borders_1[i:i+self.__size])+"}" for i in range(0,len(str_borders_1),self.__size)]
        str_borders = "{"+",".join(str_borders_2)+"}"

        output = [
            "%id: "+self._game_id,
            "\\def\\bordsHBGD"+str_borders,
            "\\begin{tikzpicture}[scale=1.2]",
            "\\draw[line width=1pt] (0,0) rectangle (" + str(S) + "," + str(S) +");",
            "\\draw[line width=0.5pt] (0,0) grid[step=1] (" + str(S) + "," + str(6) + ");",
            "\\sideItems{"+str(self.__size)+"}{"+str(self.__size)+"}{\\bordsHBGD}{2}"
        ]

        vals = list(map(lambda d:str(d) if d>=0 else ' ', self._cells.ordered_values()))
        strVals = ",\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
        output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
        output.append(strVals)
        output.append("} }{1.5}")

        if self.solution():
            vals = list(map(str, self._cells.ordered_values()))
            strVals = ",\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
            output.append("\\ifthenelse{\\showCor = 1}{")
            output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
            output.append(strVals)
            output.append("} }{1.5}")
            output.append("}{ }")
        output.append("\\end{tikzpicture}")
        return "%\n".join(output)




