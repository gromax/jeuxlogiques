from typing import List, Dict, Tuple, Optional

from modules.primitives.cellgroup import CellGroup
from modules.primitives.cell import Cell

class Constraint:
    __value:int
    __neignbours_cells:List[Cell]
    __validation_rank:int
    __iline:int
    __icol:int

    def __init__(self, iline:int, icol:int, value:int, cell:Cell, neighbours:List[Cell]):
        self.__iline = iline
        self.__icol = icol
        self.__value = value
        self.__neignbours_cells = neighbours
        self.__validation_rank = -1
        self.__cell = cell

    @property
    def iline(self) -> int:
        return self.__iline

    @property
    def icol(self) -> int:
        return self.__icol

    @property
    def value(self) -> int:
        return self.__value

    def __valid_when_knowing_cell(self, stack:List[Cell]) -> bool:
        assert self.__cell.value != -1
        current = self.__cell.value
        # on compte le nombre de murs connus
        walls_knowns = 0
        walls_unknowns = 0
        for c in self.__neignbours_cells:
            if c.value == -1:
                walls_unknowns += 1
            elif c.value != current:
                walls_knowns += 1
        if not walls_knowns <= self.__value <= walls_knowns + walls_unknowns:
            # la contrainte ne pourra être satisfaite
            return False
        if walls_unknowns == 0:
            # la contrainte est maintenant validée
            self.__validation_rank = len(stack)
            return True
        if current == 0 and walls_knowns == self.__value \
            or current == 1 and walls_knowns + walls_unknowns == self.__value:
            # tous les inconnus passent extérieur
            self.__validation_rank = len(stack)
            for c in self.__neignbours_cells:
                if c.value == -1:
                    c.value = 0
                    stack.append(c)
        return True
    
    def valid(self, stack:List[Cell]) -> bool:
        """
        test si la condition est valide
        modifie éventuellement la pile pour mettre une cellule en blanc
        """
        if self.__validation_rank >= 0:
            return True

        # premier cas, on connaît la cellule courante
        if self.__cell.value != -1:
            return self.__valid_when_knowing_cell(stack)
        # 2e cas, on ne connaît pas current
        exteriors = sum(1 for c in self.__neignbours_cells if c.value==0)
        if exteriors > self.__value:
            # la cellule courante doit passer en extérieur
            self.__cell.value = 0
            stack.append(self.__cell)
            # on peut relancer la fonction armé de cette connaissance
            return self.valid(stack)
        # dans les autres cas, je laisse en suspens
        return True
    
    def refresh(self, stacklen:int):
        if stacklen < self.__validation_rank:
            self.__validation_rank = -1

class Loopy:
    __game_id:str
    __cells:CellGroup
    __size:int
    __constraints:List[Constraint]
    __values:List[int]

    def __init_cells_content(self, contentStr:str):
        """
        initialise les cellules selon le code fournit
        ex: a22d3c1b3022a3c3a2b02b2b1b31a1d2b signifie que l'on saute 1 case puis 2 puis 2 puis saute 4 cases (d)...
        """
        self.__values = [-1]*(self.__size**2)
        self.__constraints = []
        if contentStr == "":
            return
        i = 0
        for car in contentStr:
            if car in "01234":
                # c'est un digit à placer
                c = int(car)
                self.__values[i] = c
                iline = i // self.__size
                icol = i % self.__size
                neighbours = self.__get_neighbours(iline, icol)
                self.__constraints.append(Constraint(iline, icol, c, self.__cells[iline,icol], neighbours))
                i += 1
                continue
            delta = ord(car) - ord('a') + 1
            i += delta

    def __init__(self, game_id:str):
        """
        game_id: chaîne selon jeu loopy de simon tatham
        ex: 7x7t0:a22d3c1b3022a3c3a2b02b2b1b31a1d2b
        """
        sizeStr, contentStr = game_id.split(':')
        self.__size = int(sizeStr.split("x")[0]) # assume que ce sera un carré
        self.__cells = CellGroup.make_from_size("cells", self.__size, default=Cell(-1,-1,0)) # cellule extérieure à 0
        self.__game_id = game_id
        self.__init_cells_content(contentStr)

    def __get_not_nul_cell(self) -> Optional[Tuple[int,int]]:
        """
        renvoie première cellule à valeur non nulle
        """
        for constraint in self.__constraints:
            if constraint.value != 0:
                return constraint.iline, constraint.icol
        return None
    
    def __get_neighbours(self, iline:int, icol:int) -> List[Cell]:
        coords = self.__get_neighbours_coords(iline, icol)
        return [self.__cells[line,col] for line,col in coords]

    def __get_neighbours_coords(self, iline:int, icol:int) -> List[Tuple[int,int]]:
        deltas = ((-1,0), (1,0), (0,-1), (0,1))
        return [(iline+dline,icol+dcol) for dline,dcol in deltas]

    def solution(self) -> bool:
        """
        Cherche une solution. envoie True si elle est trouvée
        """
        # je noterai noir pour une case intérieure. Associé avec la valeur 1 dans la cellule
        # blanc pour case extérieure, associée à 0
        # 1. Chercher première case avec valeur non nul et ses voisines
        start_pos = self.__get_not_nul_cell() 
        if start_pos is None:
            return False
        iline, icol = start_pos
        starting_canditates_brut = [self.__cells[iline, icol]] + self.__get_neighbours(iline, icol)
        starting_candidates = [c for c in starting_canditates_brut if not c.is_initial]
        # l'une des case sera noire
        for i in range(len(starting_candidates)):
            self.__cells.init_candidates([0,1])
            stack = []
            for j in range(i):
                stack.append(starting_candidates[j])
                stack[-1].value = 0
            stack.append(starting_candidates[i])
            stack[-1].value = 1
            if self.__try_with_start(stack):
                return True
        return False

    def __get_interior_candidate(self)->Optional[Cell]:
        """
        renvoie une cellule encore indéterminée et qui aurait une case intérieure dans ses voisines
        """
        for iline,icol in self.__cells.coords(filter = lambda c:c.value==-1):
            if len([c for c in self.__get_neighbours(iline,icol) if c.value == 1]) > 0:
                return self.__cells[iline,icol]
        return None

    def __validate_constraints(self, stack:List[Cell]) -> bool:
        """
        vérifie l'ensemble des contraintes
        """
        for c in self.__constraints:
            if not c.valid(stack):
                return False
        return True

    def __destack(self, stack:List[Cell]):
        """
        dépile jusqu'à trouver une cellule noire que l'on pourrait passer en blanc
        si cette cellule est la première, échoue
        """
        while len(stack)>0 and stack[-1].value == 0:
            c = stack.pop()
            c.reinit([0,1])
        if len(stack) == 0:
            # échec on termine
            return
        stack[-1].value = 0
        # dévalidation des contraintes 
        n = len(stack)
        # certaines contraintes ont été validées avec ce niveau de stack mais
        # avec une dernière cellule différente. Il faut donc dévalider
        # au niveau supérieur
        for c in self.__constraints:
            c.refresh(n-1)

    def __try_with_start(self, stack:List[Cell]) -> bool:
        """
        Essai avec une case intérieure en iline, icol comme point de départ
        """
        N = self.__size**2
        while 0 < len(stack) < N :
            # recherche nouveau candidat
            newcell = self.__get_interior_candidate()
            if newcell is not None:
                newcell.value = 1
                stack.append(newcell)
            else:
                # on n'a trouvé aucun candidat. Tous les inconnus seront extérieurs
                for c in self.__cells.cells(filter = lambda c:c.value==-1):
                    c.value = 0
                    stack.append(c)
            # vérification
            if len(stack) == N:
                # vérifier la connexité
                interior = self.__cells.subGroup(lambda c:c.value == 1)
                if not interior.is_connexe():
                    self.__destack(stack)
            if not(self.__validate_constraints(stack)):
                # il faut dépiler
                self.__destack(stack)

        return len(stack) == N

    def tex(self) -> str:
        """
        Retourne le code LaTeX pour générer le jeu
        """
        output = ["%id: "+self.__game_id]
        output.append("\\begin{tikzpicture}[scale=.7]")
        output.append("\\draw[line width=0.5pt] (0,0) grid[step=1] ("+str(self.__size)+","+str(self.__size)+");")
        vals = list(map(lambda d:str(d) if d>=0 else ' ', self.__values))
        strVals = ",%\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
        output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
        output.append(strVals)
        output.append("} }{1.5}")

        if self.solution():
            interior = self.__cells.subGroup(filter=lambda c:c.value == 1)
            cadre = interior.cadre()
            output.append("\\begin{scope}[shift={(0,"+str(self.__size)+")}, yscale=-1]")
            output.append(cadre.tex())
            output.append("\\end{scope}")
        output.append("\\end{tikzpicture}")
        return "%\n".join(output)

