"""
Classe de base pour les jeux de type "grille" (sudoku, kenken, etc.)
"""

from abc import ABC, abstractmethod
from typing import List

from modules.primitives.cell import Cell
from modules.primitives.cellgroup import CellGroup

class Game(ABC):
    _cells:CellGroup
    _game_id:str

    def __init__(self, cells:CellGroup, game_id:str):
        """
        game_id: chaîne selon le jeu
        """
        self._game_id = game_id
        self._cells = cells
        self._groups_to_update = []

    @abstractmethod
    def _to_update(self) -> List[CellGroup]:
        return []

    @abstractmethod
    def candidates(self) -> List[int]:
        """
        renvoie la liste des candidats envisageables pour ce jeu
        """
        return []

    @abstractmethod
    def _valid(self) -> bool:
        """
        vérifie si le jeu est valide
        """
        return True

    def is_full(self) -> bool:
        """
        renvoie True si toutes les cellules du jeu ont une valeur connue, False sinon
        """
        return self._cells.allKnown()

    def __update_candidates(self):
        """
        met à jour les candidats possibles pour chaque cellule du jeu
        """
        for g in self._to_update():
            g.update_candidates()

    def solution(self) -> bool:
        """
        calcule la solution du jeu
        """
        self._cells.init_candidates(self.candidates())
        if not self._valid():
            return False
        self.__update_candidates()
        cells:List[Cell] = self._cells.cells(filter=lambda c:not c.known)
        i = 0
        while i < len(cells):
            rep = cells[i].next()
            if rep is False:
                if i == 0:
                    return False
                i -= 1
                cells[i].uncache()
                for c in cells[i+1:]:
                    c.reinit(self.candidates())
                continue
            # nettoyage des valeurs imposées par les cellules précédentes
            self.__update_candidates()
            if not self._valid():
                cells[i].uncache()
                for c in cells[i+1:]:
                    c.reinit(self.candidates())
                continue
            # on vient d'imposer une valeur possiblement valide,
            # on peut passer à la suivante
            i += 1
        # à ce stade, toutes les cellules ont une valeur connue
        # c'est une solution (pas forcément la seule)
        return True

