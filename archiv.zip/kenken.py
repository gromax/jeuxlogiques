import re
from typing import Dict, Tuple, List

from modules.jeux.archiv.game import Game
from modules.primitives.cellgroup import CellGroup
from modules.primitives.zones import Zones

def product(lst:List[int]) -> int:
    res = 1
    for v in lst:
        res *= v
    return res

class Kenken(Game):
    __lines:List[CellGroup]
    __cols:List[CellGroup]
    __zones:List[CellGroup]
    __size:int
    __to_update:List[CellGroup]

    def __init__(self, game_id:str):
        """
        game_id: chaîne selon jeu keen de simon tatham
        """
        gridStr, opersStr = game_id.split(',')
        g = Zones.makeFromStr(gridStr)
        super().__init__(g.cells, game_id)
        self.__lines, self.__cols, self.__zones = g.zones()
        self.__size = g.width
        self.__zones.sort(key=lambda z: z.getFirstCellCoords()) # tri ordre lexicographique
        
        opers = [(it[0], int(it[1:])) for it in re.findall(r"[a-z][1-9][0-9]*", opersStr)]
        for (z, op) in zip(self.__zones, opers):
            z.data = op
        self.__to_update = self.__lines + self.__cols


    def _valid(self) -> bool:
        if self._cells.hasNoValueCell():
            return False
        if any(z.has_double() for z in self.__lines) or any(z.has_double() for z in self.__cols):
            return False
        for z in self.__zones:
            oper, value = z.data
            digits = z.values()
            if len(digits) < len(z):
                continue
            if oper == 'a' and sum(digits) != value:
                return False
            elif oper == 's' and max(digits) - min(digits) != value:
                return False
            elif oper == 'm' and product(digits) != value:
                return False
            elif oper == 'd' and max(digits) // min(digits) != value:
                return False
        return True

    def _to_update(self):
        return self.__to_update

    def candidates(self):
        return list(range(1, self.__size+1))

    def __operToTex(self, operName:str, operValue:int) -> str:
        if operName == 'd':
            op = "\\div"
        elif operName == "a":
            op = "+"
        elif operName == "s":
            op = "-"
        else:
            op = "\\times"
        return f"${operValue}{op}$"

    def tex(self):
        output = [
            "%id = "+self._game_id,
            "\\begin{tikzpicture}[scale=1]",
            "\\begin{scope}[shift={(0,6)}, yscale=-1]",
            "\\draw[dotted] (0,0) rectangle (" + str(self.__size) + ", " + str(self.__size) + ");",
            "\\draw[dotted] (0,0) grid[step=1] (" + str(self.__size) + ", " + str(self.__size) + ");"
        ]
        for z in self.__zones:
            output.append(z.cadre().tex())
        for z in self.__zones:
            oper, value = z.data
            opTex = self.__operToTex(oper, value)
            iline, icol = z.getFirstCellCoords()
            tagStr = f"\\draw ({icol},{iline}) node[below right]{{ {opTex} }};"
            output.append(tagStr)
        output.append("\\end{scope}")
        if self.solution():
            vals = list(map(str, self._cells.ordered_values()))
            strVals = ",\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
            output.append("\\ifthenelse{\\showCor = 1}{")
            output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
            output.append(strVals)
            output.append("} }{1.5}")
            output.append("}{ }")
        output.append("\\end{tikzpicture}")
        return "%\n".join(output)
