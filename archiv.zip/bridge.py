from typing import List, Optional

class Island:
    def __init__(self, value:int, line:int, col:int):
        assert 0 <= value <= 8
        self.__value = value
        self.__line = line
        self.__col = col
        self.__bridges = 0
        self.__count = []
    
    def __str__(self):
        return str(self.__value)
    
    @property
    def line(self) -> int:
        return self.__line

    @property
    def col(self) -> int:
        return self.__col
    
    def add_bridge(self):
        self.__bridges += 1
    
    def reset_count(self):
        self.__count = []
    
    def inc_count(self, value:int):
        self.__count.append(value)

    def is_valid(self) -> bool:
        s = sum(self.__count)
        return s <= self.__value <= s + 2*(self.__bridges-len(self.__count))
    

class Bridge:
    def __init__(self, orig:Island, dest:Island):
        self.__orig = orig
        self.__dest = dest
        self.__value = -1 # indéfini
        orig.add_bridge()
        dest.add_bridge()

    def __str__(self):
        return f"{self.__orig.line}/{self.__orig.col}/{self.__dest.line}/{self.__dest.col}/{self.__value}"

    @property
    def lines(self):
        v = (self.__orig.line, self.__dest.line)
        return min(v), max(v)
    
    @property
    def cols(self):
        v = (self.__orig.col, self.__dest.col)
        return min(v), max(v)

    def __intersect(self, inter1, inter2) -> bool:
        """
        inter1, inter2: tuple d'entiers ordonnés représentant un intervalle
        renvoie True si les deux intervalles ont des valeurs en commun
        """
        m1, M1 = inter1
        m2, M2 = inter2
        return m2 < M1 and m1 < M2

    def intersect(self, other:"Island") -> bool:
        if self == other:
            return False
        return self.__intersect(self.lines, other.lines) and self.__intersect(self.cols, other.cols)
    
    def count(self):
        if self.__value >=0:
            self.__orig.inc_count(self.__value)
            self.__dest.inc_count(self.__value)

    def exists(self) -> bool:
        return self.__value > 0
    
    def reset(self):
        self.__value = -1

    def next(self) -> bool:
        """
        passe à la valeur suivante dans la recherche de solution
        renvoie False si la dernière valeur a été atteinte
        """
        self.__value += 1
        if self.__value > 2:
            self.__value = -1
            return False
        return True


class BridgeGame:
    def __init__(self, size:int, values:list):
        """
        size: nombe de lignes et cols de la grille
              les nœuds sont donc en nombre size+1 x size+1
        values: tableau contenant None ou une étiquette pour mettre un nœud
        """
        self.__size = size
        self.__grid_size = size**2
        assert self.__grid_size >= len(values)
        self.__grid:List[Optional[Island]] = [None]*self.__grid_size
        for i, item in enumerate(values):
            if item is not None:
                self.__grid[i] = Island(item, i//self.__size, i%self.__size)
        self.__islands:List[Island] = [island for island in self.__grid if island is not None]
        self.__bridges:List[Bridge] = self.__make_bridges()
        self.__intersects:List[List[int]] = [self.__get_intersect(b) for b in self.__bridges]

    def __get_intersect(self, bridge:Bridge):
        return [i for i,b in enumerate(self.__bridges) if bridge.intersect(b)]

    def get_island(self, line:int, col:int):
        if not 0 <= line < self.__size or not 0 <= col < self.__size:
            return None
        return self.__grid[line*self.__size + col]
    
    @classmethod
    def make_from_id(cls, game_id:str):
        """
        game_id: chaine contenant l'id générée par les jeux de simon tatham
        renvoie un objet Slant
        exemple:
          12x12m2:a2o3a6a5a4a5a1f1v1c5c4a7b3d2b1b1d2j3a5a4e31f5a2c1a2g12a4b5a5b2a
        """
        pre, vals = game_id.split(':')
        ssize, _ = pre.split('x')
        size = int(ssize)
        values = []
        for letter in vals:
            if letter.isdigit():
                values.append(int(letter))
                continue
            j = ord(letter) - ord('a') + 1
            values += [None]*j
        return BridgeGame(size, values)
    
    def __get_island_above(self, source:Island) -> Optional[Island]:
        for li in range(source.line+1, self.__size):
            item = self.get_island(li, source.col)
            if item is not None:
                return item
        return None

    def __get_island_right(self, source:Island) -> Optional[Island]:
        for c in range(source.col+1, self.__size):
            item = self.get_island(source.line, c)
            if item is not None:
                return item
        return None

    def __make_bridges(self) -> List[Bridge]:
        bridges = []
        for item in self.__islands:
            if item is None:
                continue
            above = self.__get_island_above(item)
            if above is not None:
                bridges.append(Bridge(item, above))
            right = self.__get_island_right(item)
            if right is not None:
                bridges.append(Bridge(item, right))
        return bridges

    def __test_count(self) -> bool:
        for island in self.__islands:
            island.reset_count()
        for b in self.__bridges:
            b.count()
        for island in self.__islands:
            if not island.is_valid():
                return False
        return True
        
    def __test_intersect(self) -> bool:
        for i, listj in enumerate(self.__intersects):
            for j in listj:
                if self.__bridges[i].exists() and self.__bridges[j].exists():
                    return False
        return True

    def __test(self) -> bool:
        """
        renvoie True si la grille soluce est valide
        """
        return self.__test_count() and self.__test_intersect()

    def get_sol(self) -> bool:
        if len(self.__bridges) == 0:
            return True
        for b in self.__bridges:
            b.reset()
        cursor = 0
        while 0 <= cursor < len(self.__bridges):
            if not self.__bridges[cursor].next():
                cursor -= 1
                continue
            if self.__test():
                cursor += 1
        return cursor == len(self.__bridges)

    def __tex_grid(self):
        """
        renvoie la grille elle-même en tex
        """
        svalues = list(map(
           lambda item:' ' if item is None else str(item),
           self.__grid
        ))
        lines = [",".join(svalues[i:i+self.__size]) for i in range(0, self.__grid_size, self.__size)]
        return "\\islands{"+str(self.__size)+"}{{%\n" + \
               ',%\n'.join(lines) + " %\n"             + \
                "}}{.3}{1}"

    def __tex_soluce(self):
        if self.__bridges == []:
            return ""
        vals = [str(b) for b in self.__bridges if b.exists()]
        return "\\ifthenelse{\\showCor = 1}{\n" + \
               "\\bridgesCor{"+str(self.__size-1)+"}{ {" + ", ".join(vals) + "} }\n" + \
               "}{ }"

    def tex(self):
        """
        renvoie la version tex
        """
        self.get_sol()
        return "\n".join([
            "\\begin{tikzpicture}[scale=1]",
            "\\dottedGrid{" + str(self.__size-1) + "}",
            self.__tex_soluce(),
            self.__tex_grid(),
            "\\end{tikzpicture}",
        ])
    
if __name__ == '__main__':
    game_id = input("id = ")
    s = BridgeGame.make_from_id(game_id)
    print(s.tex())



