# site https://fr.puzzle-thermometers.com/

from typing import List, Tuple
from enum import Enum
from math import asin, degrees

class Forme(Enum):
    START=1
    END=2
    STRAIGHT=3
    CURVE=4

    @classmethod
    def to_str(cls, forme:"Forme") -> str:
        if forme == Forme.CURVE:
            return "c"
        if forme == Forme.STRAIGHT:
            return "-"
        if forme == Forme.START:
            return "s"
        return "e"

class Cardinal(Enum):
    NORTH=0
    EAST=1
    SOUTH=2
    WEST=3
    
    @classmethod
    def clockwise(cls, cardinal:"Cardinal") -> "Cardinal":
        if cardinal == Cardinal.NORTH:
            return Cardinal.EAST
        if cardinal == Cardinal.EAST:
            return Cardinal.SOUTH
        if cardinal == Cardinal.SOUTH:
            return Cardinal.WEST
        return Cardinal.NORTH

    @classmethod
    def opposite(cls, cardinal:"Cardinal") -> "Cardinal":
        if cardinal == Cardinal.NORTH:
            return Cardinal.SOUTH
        if cardinal == Cardinal.EAST:
            return Cardinal.WEST
        if cardinal == Cardinal.SOUTH:
            return Cardinal.NORTH
        return Cardinal.EAST
    
    @classmethod
    def to_str(cls, cardinal:"Cardinal") -> str:
        if cardinal == Cardinal.NORTH:
            return "N"
        if cardinal == Cardinal.EAST:
            return "E"
        if cardinal == Cardinal.SOUTH:
            return "S"
        return "W"
    
    @classmethod
    def degrees(cls, cardinal:"Cardinal") -> int:
        if cardinal == Cardinal.NORTH:
            return 0
        if cardinal == Cardinal.EAST:
            return 90
        if cardinal == Cardinal.SOUTH:
            return 180
        return 270

    @classmethod
    def shift(cls, cardinal:"Cardinal") -> Tuple[int,int]:
        if cardinal == Cardinal.NORTH:
            return -1,0
        if cardinal == Cardinal.EAST:
            return 0,1
        if cardinal == Cardinal.SOUTH:
            return 1,0
        return 0,-1


class Cell:
    RADIUS = 0.3
    MARGIN = 0.1
    ANGLE1 = round(degrees(asin(0.1/0.3)) - 90,1)
    ANGLE2 = round(- degrees(asin(0.1/0.3)) + 270,1)
    __forme:Forme
    __line:int
    __col:int
    __on:bool
    __off:bool
    __neighbourgs_cardinaux:Tuple[Cardinal]

    def __init__(self, forme:Forme, line:int, col:int, orientation:Cardinal):
        self.__forme = forme
        self.__line = line
        self.__col = col
        self.__on = False
        self.__off = False
        if self.__forme == Forme.STRAIGHT:
            self.__neighbourgs_cardinaux = (orientation, Cardinal.opposite(orientation))
        elif self.__forme == Forme.CURVE:
            self.__neighbourgs_cardinaux = (orientation, Cardinal.clockwise(orientation))
        else:
            self.__neighbourgs_cardinaux = (orientation,)

    def reaxe(self, prev_coords:Tuple[int,int]):
        coords = self.neighbour_coords(self.__neighbourgs_cardinaux[0])
        if coords != prev_coords:
            self.__neighbourgs_cardinaux = self.__neighbourgs_cardinaux[::-1]
    
    @classmethod
    def from_content(self, forme:str, line:int, col:int) -> "Cell":
        if "curve" in forme:
            forme_  = Forme.CURVE
        elif "straight" in forme:
            forme_ = Forme.STRAIGHT
        elif "end" in forme:
            forme_ = Forme.END
        else:
            assert "start" in forme
            forme_ = Forme.START
        if "r1" in forme:
            orientation = Cardinal.EAST
        elif "r2" in forme:
            orientation = Cardinal.SOUTH
        elif "r3" in forme:
            orientation = Cardinal.WEST
        else:
            orientation = Cardinal.NORTH
        return Cell(forme_, line, col, orientation)

    def neighbour_coords(self, orientation:Cardinal) -> Tuple[int,int]:
        if orientation == Cardinal.NORTH:
            return self.line-1, self.col
        if orientation == Cardinal.EAST:
            return self.line, self.col+1
        if orientation == Cardinal.SOUTH:
            return self.line+1, self.col
        return self.line, self.col-1

    def is_neighbour(self, c:"Cell") -> bool:
        return (c.line, c.col) in self.get_neighbours()

    def get_neighbours(self) -> List[Tuple[int, int]]:
        return [self.neighbour_coords(ori) for ori in self.__neighbourgs_cardinaux]
    def __str__(self) -> str:
        return f"line:{self.line}, col:{self.col}, voisins:{''.join(Cardinal.to_str(ori) for ori in self.__neighbourgs_cardinaux)}"

    @property
    def line(self) -> int:
        return self.__line

    @property
    def col(self) -> int:
        return self.__col
    
    @property
    def temp(self) -> int:
        return self.__temp

    def is_start(self) -> bool:
        return self.__forme == Forme.START
    
    def is_end(self) -> bool:
        return self.__forme == Forme.END
    
    def is_straight(self) -> bool:
        return self.__forme == Forme.STRAIGHT
    
    def tex(self, last:bool, aller:bool) -> str:
        if self.is_start():
            r = Cardinal.degrees(self.__neighbourgs_cardinaux[0])
            start = f"({self.col},{self.line}) ++ ({Cell.ANGLE1+r}:{Cell.RADIUS})"
            arc = f" arc ({Cell.ANGLE1+r}:{Cell.ANGLE2+r}:{Cell.RADIUS})"
            if last:
                dl2, dc2 = Cardinal.shift(self.__neighbourgs_cardinaux[0])
                x3 = self.col + dl2*Cell.MARGIN + dc2*0.5
                y3 = self.line - dc2*Cell.MARGIN + dl2*0.5
                x4 = self.col - dl2*Cell.MARGIN + dc2*0.5
                y4 = self.line + dc2*Cell.MARGIN + dl2*0.5
                return f"{start}{arc} -- ({x3},{y3}) -- ({x4},{y4})"
            return start + arc
        if self.is_end():
            dl, dc = Cardinal.shift(self.__neighbourgs_cardinaux[0])
            r = Cardinal.degrees(self.__neighbourgs_cardinaux[0])
            x = self.col - dl*Cell.MARGIN
            y = self.line + dc*Cell.MARGIN
            return f"({x},{y}) arc ({r}:{180+r}:{Cell.MARGIN})"
        
        if self.is_straight():
            if aller:
                dl, dc = Cardinal.shift(self.__neighbourgs_cardinaux[0])
            else:
                dl, dc = Cardinal.shift(self.__neighbourgs_cardinaux[1])
            if last:
                x = self.col - dl*Cell.MARGIN - dc*0.5
                y = self.line + dc*Cell.MARGIN - dl*0.5
                x2 = self.col + dl*Cell.MARGIN - dc*0.5
                y2 = self.line - dc*Cell.MARGIN - dl*0.5
                return f"({x},{y}) -- ({x2},{y2})"
            x = self.col - dl*Cell.MARGIN
            y = self.line + dc*Cell.MARGIN
            return f"({x},{y})"

        ns = self.__neighbourgs_cardinaux if aller else self.__neighbourgs_cardinaux[::-1]
        dl, dc = Cardinal.shift(ns[0])
        dl2, dc2 = Cardinal.shift(ns[1])
        dls = -dl + dl2
        dcs = -dc + dc2
        print(dls,dcs)
        x = self.col + dls*Cell.MARGIN
        y = self.line - dcs*Cell.MARGIN
        x2 = self.col - dls*Cell.MARGIN
        y2 = self.line + dcs*Cell.MARGIN
        if last:
            x3 = self.col + dl2*Cell.MARGIN + dc2*0.5
            y3 = self.line - dc2*Cell.MARGIN + dl2*0.5
            x4 = self.col - dl2*Cell.MARGIN + dc2*0.5
            y4 = self.line + dc2*Cell.MARGIN + dl2*0.5
            return f"({x},{y}) -- ({x3},{y3}) -- ({x4},{y4}) -- ({x2},{y2})"
        return f"({x},{y})"
    
    def set_on(self):
        assert not self.__off
        self.__on = True
    
    def set_off(self):
        assert not self.__on
        self.__off = True

    @property
    def off(self) -> bool:
        return self.__off
    
    @property
    def on(self) -> bool:
        return self.__on

class Thermometre:

    __cells:List[Cell]

    def __init__(self):
        self.__cells = []

    def add_cell(self, cell:Cell):
        if len(self.__cells)>0:
            p = self.__cells[-1]
            cell.reaxe((p.line, p.col))
        self.__cells.append(cell)

    @property
    def temp(self) -> int:
        return len([c for c in self.__cells if c.on])

    def __str__(self) -> str:
        return "-".join(f"({c.line},{c.col})" for c in self.__cells)

    def off_col(self, col:int, number:int):
        cells = [c for c in self.__cells if c.col == col and not c.on and not c.off]
        assert number <= len(cells)
        first_to_off = cells[-number]
        for c in self.__cells[::-1]:
            c.set_off()
            if c == first_to_off:
                break

    def on_col(self, col:int, number:int):
        cells = [c for c in self.__cells if c.col == col and not c.on and not c.off]
        assert number <= len(cells)
        last_to_on = cells[number-1]
        for c in self.__cells:
            c.set_on()
            if c == last_to_on:
                break

    def off_line(self, line:int, number:int):
        cells = [c for c in self.__cells if c.line == line and not c.on and not c.off]
        assert number <= len(cells)
        first_to_off = cells[-number]
        for c in self.__cells[::-1]:
            c.set_off()
            if c == first_to_off:
                break

    def on_line(self, line:int, number:int):
        cells = [c for c in self.__cells if c.line == line and not c.on and not c.off]
        assert number <= len(cells)
        last_to_on = cells[number-1]
        for c in self.__cells:
            c.set_on()
            if c == last_to_on:
                break

    def get_unknown_line_count(self, line:int) -> int:
        return sum(1 for c in self.__cells if c.line==line and not c.on and not c.off)
    
    def get_unknown_col_count(self, col:int) -> int:
        return sum(1 for c in self.__cells if c.col==col and not c.on and not c.off)

    def tex(self, sol:bool=False) -> str:
        cells = self.__cells if not sol else [c for c in self.__cells if c.on]
        if cells == []:
            return ""
        if len(cells) == 1:
            coords = cells[0].tex(True, True)
        elif len(cells) == 2:
            coords = cells[0].tex(False,True) + " -- " + cells[1].tex(True,True)
        else:
            rev = cells[::-1]
            coords = cells[0].tex(False,True) + " -- " + " -- ".join([c.tex(False,True) for c in cells[1:-1]]) + " -- " + cells[-1].tex(True,True) + " -- " + " -- ".join([c.tex(False,False) for c in rev[1:-1]])

        coords += " -- cycle;"
        if sol:
            return "\\fill[red] "+coords
        return "\draw[line width=.5] "+coords

class Thermometres:
    __size : int
    __cells : List[Cell]
    __top:List[int]
    __left:List[int]
    def __init__(self, borders:List[int], cells:List[Cell]):
        self.__size = len(borders)//2
        self.__top = borders[:self.__size]
        self.__left = borders[self.__size:]
        assert sum(self.__top) == sum(self.__left)
        self.__cells = [None for _ in range(self.__size**2)]
        for c in cells:
            self.__set_cell(c)
    
    def __set_cell(self, cell:Cell):
        indice = cell.line*self.__size + cell.col
        self.__cells[indice] = cell

    def __get_start(self):
        return [c for c in self.__cells if c.is_start()]
    
    def get_cell(self, line:int, col:int) -> Cell:
        assert 0 <= line < self.__size and 0 <= col < self.__size
        indice = line*self.__size + col
        return self.__cells[indice]

    def get_thermos(self) -> List[Thermometre]:
        ts = []
        for s in self.__get_start():
            t:List[Cell] = []
            t.append(s)
            while not t[-1].is_end():
                assert len(t)<len(self.__cells)
                voisins = t[-1].get_neighbours()
                if len(voisins) == 1:
                    line, col = voisins[0]
                    c = self.get_cell(line, col)
                    t.append(c)
                    continue
                assert len(t)>1
                c1 = self.get_cell(*voisins[0])
                c2 = self.get_cell(*voisins[1])
                
                assert c1 == t[-2] or c2 == t[-2]
                if c1 == t[-2]:
                    t.append(c2)
                else:
                    t.append(c1)
                
            thermo = Thermometre()
            for c in t:
                thermo.add_cell(c)
            ts.append(thermo)
        return ts


    @classmethod
    def get_thermos_from_content(cls, content:str) -> List[Cell]:
        values = []
        while 'class="cell selectable' in content:
            i = content.index('class="cell selectable')
            deb = lastIndex("<div", content[:i])
            fin = content.index("</div>", i) + len("</div>")
            line = content[deb:fin]
            forme = get_form(line)
            x,y = get_xy(line)
            values.append((x, y, forme))
            content = content[fin:]
        s = int(round(len(values)**0.5,0))
        xmin = min(values, key=lambda item:item[0])[0]
        xmax = max(values, key=lambda item:item[0])[0]
        w = (xmax-xmin)//(s-1)
        ymin = min(values, key=lambda item:item[1])[1]
        ymax = max(values, key=lambda item:item[1])[1]
        h = (ymax-ymin)//(s-1)
        return [Cell.from_content(forme, (y-ymin)//h, (x-xmin)//w) for x,y,forme in values]
    
    @classmethod
    def get_borders_from_content(cls, content:str) -> List[int]:
        values = []
        while 'class="cell task' in content:
            i = content.index('class="cell task')
            deb = lastIndex("<div", content[:i])
            fin = content.index("</div>", i) + len("</div>")
            line = content[deb:fin-6]
            j = lastIndex(">", line)
            v = int(line[j+1:])
            values.append(v)
            content = content[fin:]
        return values
    

    def __verify(self, thermos:List[Thermometre]) -> bool:
        for line in range(self.__size):
            if len([1 for col in range(self.__size) if self.get_cell(line, col).on]) != self.__left[line]:
                return False
        for col in range(self.__size):
            if len([1 for line in range(self.__size) if self.get_cell(line, col).on]) != self.__top[col]:
                return False
        return True

    def __try_something(self, thermos:List[Thermometre]) -> bool:
        for col in range(self.__size):
            if self.__try_column(thermos, col):
                return True
        for line in range(self.__size):
            if self.__try_line(thermos, line):
                return True
        return False

    def __try_column(self, thermos:List[Thermometre], col:int) -> bool:
        """
        essaie de rajouter une info dans une colonne
        """
        points = self.__top[col]
        ons = len([1 for line in range(self.__size) if self.get_cell(line, col).on])
        offs = len([1 for line in range(self.__size) if self.get_cell(line, col).off])
        for t in thermos:
            u = t.get_unknown_col_count(col)
            forced_off = u - (points - ons)
            if forced_off >0:
                t.off_col(col, forced_off)
                return True
            forced_on = u - (self.__size - points - offs)
            if forced_on > 0:
                t.on_col(col, forced_on)
                return True
        return False

    def __try_line(self, thermos:List[Thermometre], line:int) -> bool:
        """
        essaie de rajouter une info dans une ligne
        """
        points = self.__left[line]
        ons = len([1 for col in range(self.__size) if self.get_cell(line, col).on])
        offs = len([1 for col in range(self.__size) if self.get_cell(line, col).off])
        for t in thermos:
            u = t.get_unknown_line_count(line)
            forced_off = u - (points - ons)
            if forced_off >0:
                t.off_line(line, forced_off)
                return True
            forced_on = u - (self.__size - points - offs)
            if forced_on > 0:
                t.on_line(line, forced_on)
                return True
        return False

    def sol(self) -> Tuple[bool,List[Thermometre]]:
        thermos = self.get_thermos()
        while self.__try_something(thermos):
            pass
        return self.__verify(thermos), thermos

    def tex(self):
        success, thermos = self.sol()
        S = self.__size
        out = [
            "\\def\\bordsHBGD{ {" + ",".join(str(it) for it in self.__top) + "},{ },{" + ",".join(str(it) for it in self.__left) + "},{ } }",
            "\\begin{tikzpicture}[scale=1]",
            "\\draw[line width=1pt] (0,0) rectangle (" + str(S) + "," + str(S) + ");",
            "\\draw[line width=0.5pt] (0,0) grid[step=1] (" + str(S) + "," + str(S) + ");",
            "\\sideItems{"+str(S)+"}{"+str(S)+"}{\\bordsHBGD}{2}",
            "\\begin{scope}[shift={(0,"+str(S)+")}, yscale=-1]",
            "\\begin{scope}[shift={(.5,0.5)}]"
        ]
        if success:
            out.append("\\ifthenelse{\\showCor = 1}{")
            out.append("\n".join(t.tex(True) for t in thermos))
            out.append("}{ }")
        out.append("\n".join(t.tex(False) for t in thermos))
        out.append("\\end{scope}")
        out.append("\\end{scope}")
        out.append("\\end{tikzpicture}")
        return "\n".join(out)



def lastIndex(needle, meule):
    needle = needle[::-1]
    return len(meule) - meule[::-1].index(needle) - len(needle)

def get_form(line):
    i = line.index("cell selectable ")+ len("cell selectable ")
    j = line.index(" cell-off")
    return line[i:j]

def get_xy(line):
    i = line.index("top: ") + len("top: ")
    j = line.index("px", i+1)
    y = int(line[i:j])
    i = line.index("left: ") + len("left: ")
    j = line.index("px", i+1)
    x = int(line[i:j])
    return x,y


if __name__ == "__main__":
    filename = input("nom de fichier :")
    with open(filename, 'r') as file:
        content = file.read()
    borders = Thermometres.get_borders_from_content(content)
    cells = Thermometres.get_thermos_from_content(content)
    th = Thermometres(borders, cells)
    #th.sol()
    print(th.tex())

