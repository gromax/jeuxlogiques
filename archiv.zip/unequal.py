from typing import List
from modules.jeux.archiv.game import Game
from modules.primitives.cellgroup import CellGroup

class TagCell:
    """
    Représente une cellule d'une zone de jeu
    """
    __value:int
    __iline:int
    __icol:int
    __up:bool
    __down:bool
    __left:bool
    __right:bool
    def __init__(self, iline:int, icol:int, tag:str):
        self.__value = int(tag[0])
        self.__iline = iline
        self.__icol = icol
        n = tag[1:]
        self.__up = 'U' in n
        self.__down = 'D' in n
        self.__left = 'L' in n
        self.__right = 'R' in n
    @property
    def value(self) -> int:
        return self.__value
    @property
    def line(self) -> int:
        return self.__iline
    @property
    def col(self) -> int:
        return self.__icol
    @property
    def up(self) -> bool:
        return self.__up
    @property
    def down(self) -> bool:
        return self.__down
    @property
    def left(self) -> bool:
        return self.__left
    @property
    def right(self) -> bool:
        return self.__right
    def texcoords(self, **options):
       """
       Si option lexicographic, seulement les symboles vers la droite et le bas
       """
       assert set(options) <= {"lexicographic"}
       lex = (options.get("lexicographic") == True)
       output = []
       if self.up and not lex:
           output.append(f"{self.__icol}/{self.__iline}/270")
       if self.down:
           output.append(f"{self.__icol}/{self.__iline}/90")
       if self.left and not lex:
           output.append(f"{self.__icol}/{self.__iline}/180")
       if self.right:
           output.append(f"{self.__icol}/{self.__iline}/0")
       return output

class Unequal(Game):
    """
    Grille de jeu pour unequal
    """
    __values:List[TagCell]
    __size:int
    __lines:List[CellGroup]
    __cols:List[CellGroup]
    __to_update: List[CellGroup]

    def __init__(self, game_id:str):
        """
        game_id: chaîne selon jeu keen de simon tatham
        """
        sizeStr, valuesStr = game_id.split(':')
        self.__size = int(sizeStr)
        cells = CellGroup.make_from_size("cells", self.__size)
        super().__init__(cells, game_id)

        valuesStrList = valuesStr.split(',')[:self.__size**2]
        self.__values = [TagCell(i//self.__size, i%self.__size, v) for i, v in enumerate(valuesStrList)]
        self.__lines = [CellGroup(f"line {i}") for i in range(self.__size)]
        self.__cols = [CellGroup(f"col {i}") for i in range(self.__size)]
        self.__to_update = self.__lines + self.__cols

        for v in self.__values:
            cell = self._cells[v.line, v.col]
            if v.value > 0:
                cell.set_initial(v.value)
            self.__lines[v.line].add_coord(v.line, v.col, cell)
            self.__cols[v.col].add_coord(v.line, v.col, cell)

    def candidates(self):
        return list(range(1, self.__size+1))

    def _to_update(self):
        return self.__to_update

    def _valid(self) -> bool:
        """
        renvoie True si les inégalités sont respectées, False sinon
        """
        if self._cells.hasNoValueCell():
            return False
        if any(z.has_double() for z in self.__to_update):
            return False
        for v in self.__values:
            iline = v.line
            icol = v.col
            cell = self._cells[iline,icol]
            if not cell.known:
                continue
            currentVal = cell.value
            if v.up:
                upVal = self._cells[iline-1,icol].value
                if upVal != -1 and currentVal < upVal:
                    return False
            if v.down:
                downVal = self._cells[iline+1,icol].value
                if downVal != -1 and currentVal < downVal:
                    return False
            if v.left:
                leftVal = self._cells[iline,icol-1].value
                if leftVal != -1 and currentVal < leftVal:
                    return False
            if v.right:
                rightVal = self._cells[iline,icol+1].value
                if rightVal != -1 and currentVal < rightVal:
                    return False
        return True

    def tex(self) -> str:
        """
        Retourne le code LaTeX pour générer le jeu
        """
        output = ["%id: "+self._game_id]
        output.append("\\begin{tikzpicture}[scale=1.5]")
        output.append("\\inequalGrid{"+str(self.__size)+"}")
        ineqSymbols = ", ".join(sum([v.texcoords() for v in self.__values], []))
        output.append("\\begin{scope}[shift={(0.5,"+str(self.__size-0.5)+")}, yscale=-1]")
        output.append("  \\foreach \\x/\\y/\\r in {"+ineqSymbols+"} {")
        output.append("    \\begin{scope}[shift={(\\x,\\y)}, rotate=\\r] \\draw[line width=2pt] (.4,-.2) --++ (.2,.2) --++ (-.2,.2);\\end{scope}")
        output.append("  }")
        output.append("\\end{scope}")
        vals = [str(v.value) if v.value > 0 else " " for v in self.__values]
        strVals = ",%\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
        output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
        output.append(strVals)
        output.append("} }{1.5}")

        if self.solution():
            vals = list(map(str, self._cells.ordered_values()))
            strVals = ",\n".join([",".join(vals[i:i+self.__size]) for i in range(0, len(vals), self.__size)])
            output.append("\\ifthenelse{\\showCor = 1}{")
            output.append("\\showList{"+str(self.__size)+"}{"+str(self.__size)+"}{ {")
            output.append(strVals)
            output.append("} }{1.5}")
            output.append("}{ }")

        output.append("\\end{tikzpicture}")
        return "%\n".join(output)

